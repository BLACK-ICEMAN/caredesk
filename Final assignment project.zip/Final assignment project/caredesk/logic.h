/* logic.h - the "brain" of the program: all rules and calculations.
 * These functions do NOT use GTK. They return 1 on success and 0 on
 * failure. When they fail they write a readable reason into "msg",
 * and the UI simply shows that text in an error dialog. */
#ifndef LOGIC_H
#define LOGIC_H

#include "models.h"

#define MSG_SIZE 200            /* size of the message buffers used everywhere */

/* Fixed lists shared with the UI */
extern const char  *day_names[7];
extern const char  *time_slots[NUM_SLOTS];
extern const char  *ward_names[NUM_WARDS];
extern const double ward_rates[NUM_WARDS];

/* Searching: each returns the array index, or -1 when not found */
int find_patient(int id);
int find_doctor(int id);
int find_appointment(int id);
int find_active_admission(int patient_id);
int find_unpaid_bill(int patient_id);

/* Activity history */
void log_activity(const char *operation, int patient_id, int doctor_id,
                  const char *description);

/* Patients, doctors */
int add_patient(const Patient *p, char *msg);
int can_remove_patient(int patient_id, char *msg);
int remove_patient(int patient_id, char *msg);
int add_doctor(const Doctor *d, char *msg);
int remove_doctor(int doctor_id, char *msg);

/* Appointments and medical records */
int schedule_appointment(int patient_id, int doctor_id, const char *date,
                         const char *slot, char *msg, int *new_id);
int change_appointment_status(int appointment_id, const char *new_status,
                              char *msg);
int record_visit(int appointment_id, const char *symptoms,
                 const char *diagnosis, const Medicine meds[], int med_count,
                 const char *followup_date, char *msg);

/* Admissions */
int admit_patient(int patient_id, int ward, int bed_number,
                  const char *admission_date, char *msg);
int discharge_patient(int patient_id, const char *discharge_date, char *msg);

/* Billing */
int generate_bill(int patient_id, double medicine_charges, double lab_charges,
                  char *msg, int *bill_index);
int set_bill_status(int bill_index, const char *new_status);
int apply_discount(int patient_id, int percent, const char *reason, char *msg);
void build_bill_text(int bill_index, char *buffer, int size);

/* Login and user accounts */
extern int current_user_index;                 /* who is logged in (-1 = nobody) */
unsigned int hash_password(const char *password);
void ensure_default_admin(void);               /* creates admin/admin123 on first run */
int  default_admin_unchanged(void);            /* 1 while admin still has the default password */
int  login_user(const char *username, const char *password, char *msg);
void log_logout(void);
int  change_password(const char *old_password, const char *new_password,
                     const char *confirm_password, char *msg);
int  add_user(const char *username, const char *password, const char *role, char *msg);

/* Report and files */
void build_report_text(char *buffer, int size);
int  save_text_file(const char *filename, const char *text);

#endif
