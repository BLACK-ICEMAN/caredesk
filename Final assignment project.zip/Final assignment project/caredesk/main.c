/* main.c - program entry point: load data, log in, show window, save data. */
#include <gtk/gtk.h>
#include "storage.h"
#include "logic.h"
#include "ui.h"

int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);     /* start GTK                                       */
    load_all_data();            /* read the .dat files (empty on first run)        */
    ensure_default_admin();     /* first run: create the account admin / admin123  */

    /* Show the login window. After a successful login show the main window.
     * If the user clicked Logout we loop back to the login window; if they
     * closed the window with X the program ends. */
    while (show_login_dialog()) {
        create_main_window();
        gtk_main();             /* wait for clicks until the window is closed      */
        log_logout();           /* write "logged out" in the activity history      */
        if (!was_logout_requested()) {
            break;
        }
    }
    save_all_data();            /* final save when the program closes              */
    return 0;
}
