/* validation.c - helper checks for text and dates. */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "validation.h"

/* ---------- Text helpers ---------- */

int is_blank(const char *text)
{
    int i;
    for (i = 0; text[i] != '\0'; i++) {
        if (!isspace((unsigned char)text[i])) {
            return 0;               /* found a real character */
        }
    }
    return 1;
}

int is_all_digits(const char *text)
{
    int i;
    if (text[0] == '\0') {
        return 0;                   /* empty text is not a number */
    }
    for (i = 0; text[i] != '\0'; i++) {
        if (!isdigit((unsigned char)text[i])) {
            return 0;
        }
    }
    return 1;
}

/* Used for allergies: "None", "no", "-" and empty all mean "no allergy". */
int has_real_text(const char *text)
{
    char lower[80];
    int i;

    if (is_blank(text)) {
        return 0;
    }
    /* make a lower-case copy so "NONE" and "none" are treated the same */
    for (i = 0; text[i] != '\0' && i < 79; i++) {
        lower[i] = (char)tolower((unsigned char)text[i]);
    }
    lower[i] = '\0';
    trim_text(lower);

    if (strcmp(lower, "none") == 0 || strcmp(lower, "no") == 0 ||
        strcmp(lower, "nil") == 0  || strcmp(lower, "n/a") == 0 ||
        strcmp(lower, "-") == 0) {
        return 0;
    }
    return 1;
}

void trim_text(char *text)
{
    int start = 0;
    int end = (int)strlen(text) - 1;
    int i;

    while (text[start] != '\0' && isspace((unsigned char)text[start])) {
        start++;                    /* skip spaces at the front */
    }
    while (end >= start && isspace((unsigned char)text[end])) {
        end--;                      /* skip spaces at the back  */
    }
    /* shift the good part to the front of the array */
    for (i = 0; i <= end - start; i++) {
        text[i] = text[start + i];
    }
    text[end - start + 1] = '\0';
}

/* ---------- Date helpers ---------- */

static int is_leap_year(int year)
{
    if (year % 400 == 0) return 1;
    if (year % 100 == 0) return 0;
    if (year % 4 == 0)   return 1;
    return 0;
}

int is_valid_date(const char *date)
{
    int days_in_month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int year, month, day, i;

    if (strlen(date) != 10) {
        return 0;
    }
    /* check the shape: 4 digits, '-', 2 digits, '-', 2 digits */
    for (i = 0; i < 10; i++) {
        if (i == 4 || i == 7) {
            if (date[i] != '-') return 0;
        } else {
            if (!isdigit((unsigned char)date[i])) return 0;
        }
    }
    sscanf(date, "%d-%d-%d", &year, &month, &day);

    if (year < 1900 || year > 2100) return 0;
    if (month < 1 || month > 12)    return 0;
    if (is_leap_year(year)) {
        days_in_month[1] = 29;      /* February has 29 days in a leap year */
    }
    if (day < 1 || day > days_in_month[month - 1]) return 0;
    return 1;
}

void get_today(char *out)
{
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(out, 11, "%Y-%m-%d", local);
}

void get_timestamp(char *out)
{
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(out, 20, "%Y-%m-%d %H:%M:%S", local);
}

/* Because dates look like YYYY-MM-DD, comparing them as text with strcmp
 * gives the same answer as comparing them as real dates. */
int is_future_date(const char *date)
{
    char today[11];
    get_today(today);
    return strcmp(date, today) > 0;
}

/* Counts the days since 1900-01-01 (which is day number 1).
 * We use this for both "day of the week" and "days between two dates". */
static long date_to_day_number(const char *date)
{
    int days_in_month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int year, month, day, y, m;
    long total = 0;

    sscanf(date, "%d-%d-%d", &year, &month, &day);

    for (y = 1900; y < year; y++) {          /* add all the whole years before */
        total += is_leap_year(y) ? 366 : 365;
    }
    if (is_leap_year(year)) {
        days_in_month[1] = 29;
    }
    for (m = 0; m < month - 1; m++) {        /* add the whole months before    */
        total += days_in_month[m];
    }
    total += day;                            /* add the days in this month     */
    return total;
}

/* 1900-01-01 was a Monday, so (day number - 1) % 7 gives 0 = Monday. */
int day_of_week(const char *date)
{
    return (int)((date_to_day_number(date) - 1) % 7);
}

int days_between(const char *from, const char *to)
{
    return (int)(date_to_day_number(to) - date_to_day_number(from));
}

/* Gives the date that is "offset_days" away from today (negative = in the past).
 * We work at 12:00 noon so daylight-saving changes can never shift the date. */
void date_plus_days(int offset_days, char *out)
{
    time_t now = time(NULL);
    struct tm moment = *localtime(&now);

    moment.tm_hour = 12;
    moment.tm_min = 0;
    moment.tm_sec = 0;
    moment.tm_mday += offset_days;      /* may be more than 31: mktime fixes it */
    mktime(&moment);
    strftime(out, 11, "%Y-%m-%d", &moment);
}

int calculate_age(const char *dob)
{
    char today[11];
    int birth_year, birth_month, birth_day;
    int now_year, now_month, now_day;
    int age;

    get_today(today);
    sscanf(dob,   "%d-%d-%d", &birth_year, &birth_month, &birth_day);
    sscanf(today, "%d-%d-%d", &now_year, &now_month, &now_day);

    age = now_year - birth_year;
    /* birthday not reached yet this year? then subtract one */
    if (now_month < birth_month ||
        (now_month == birth_month && now_day < birth_day)) {
        age--;
    }
    return age;
}
