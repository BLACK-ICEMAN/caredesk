/* storage.h - saving and loading all data to/from binary .dat files. */
#ifndef STORAGE_H
#define STORAGE_H

void load_all_data(void);   /* call once at start-up        */
void save_all_data(void);   /* call after changes and at exit */

#endif
