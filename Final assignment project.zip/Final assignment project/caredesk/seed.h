/* seed.h - fills an empty system with realistic sample (demo) data. */
#ifndef SEED_H
#define SEED_H

/* Returns 1 on success. Returns 0 and writes the reason into msg when the
 * user is not an Admin or when the system already has doctors/patients. */
int load_demo_data(char *msg);

#endif
