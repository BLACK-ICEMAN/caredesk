/* logic.c - all business rules: registering, booking, admitting, billing...
 * Every function checks its inputs first, then changes the arrays, then
 * writes a line in the activity history. */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "logic.h"
#include "validation.h"

const char  *day_names[7] = {"Monday", "Tuesday", "Wednesday", "Thursday",
                             "Friday", "Saturday", "Sunday"};
const char  *time_slots[NUM_SLOTS] = {"08:00", "09:00", "10:00", "11:00",
                                      "12:00", "13:00", "14:00", "15:00",
                                      "16:00", "17:00"};
const char  *ward_names[NUM_WARDS] = {"General", "ICU", "Maternity", "Paediatric"};
const double ward_rates[NUM_WARDS] = {20000.0, 80000.0, 35000.0, 25000.0};

/* ====================== Searching ====================== */

int find_patient(int id)
{
    int i;
    for (i = 0; i < patient_count; i++) {
        if (patients[i].id == id) return i;
    }
    return -1;
}

int find_doctor(int id)
{
    int i;
    for (i = 0; i < doctor_count; i++) {
        if (doctors[i].id == id) return i;
    }
    return -1;
}

int find_appointment(int id)
{
    int i;
    for (i = 0; i < appointment_count; i++) {
        if (appointments[i].id == id) return i;
    }
    return -1;
}

int find_active_admission(int patient_id)
{
    int i;
    for (i = 0; i < admission_count; i++) {
        if (admissions[i].patient_id == patient_id && admissions[i].is_active) {
            return i;
        }
    }
    return -1;
}

int find_unpaid_bill(int patient_id)
{
    int i;
    for (i = 0; i < bill_count; i++) {
        if (bills[i].patient_id == patient_id &&
            strcmp(bills[i].status, "Unpaid") == 0) {
            return i;
        }
    }
    return -1;
}

/* ====================== Activity history ====================== */

void log_activity(const char *operation, int patient_id, int doctor_id,
                  const char *description)
{
    int i;
    HistoryEntry *entry;

    if (history_count >= MAX_HISTORY) {
        /* list is full: throw away the oldest entry by shifting everything up */
        for (i = 1; i < MAX_HISTORY; i++) {
            history[i - 1] = history[i];
        }
        history_count = MAX_HISTORY - 1;
    }
    entry = &history[history_count];
    get_timestamp(entry->timestamp);
    snprintf(entry->operation, sizeof(entry->operation), "%s", operation);
    entry->patient_id = patient_id;
    entry->doctor_id = doctor_id;
    snprintf(entry->description, sizeof(entry->description), "%s", description);
    history_count++;
}

/* ====================== Patients ====================== */

int add_patient(const Patient *p, char *msg)
{
    char text[MSG_SIZE];

    if (p->id <= 0) {
        snprintf(msg, MSG_SIZE, "Patient ID must be a positive number.");
        return 0;
    }
    if (find_patient(p->id) != -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d already exists.", p->id);
        return 0;
    }
    if (is_blank(p->full_name)) {
        snprintf(msg, MSG_SIZE, "Full name cannot be empty.");
        return 0;
    }
    if (!is_valid_date(p->dob)) {
        snprintf(msg, MSG_SIZE, "Date of birth must be a real date in YYYY-MM-DD format.");
        return 0;
    }
    if (is_future_date(p->dob)) {
        snprintf(msg, MSG_SIZE, "Date of birth cannot be in the future.");
        return 0;
    }
    if (!is_all_digits(p->phone)) {
        snprintf(msg, MSG_SIZE, "Phone number must contain digits only.");
        return 0;
    }
    if (patient_count >= MAX_PATIENTS) {
        snprintf(msg, MSG_SIZE, "The patient list is full (%d patients).", MAX_PATIENTS);
        return 0;
    }

    patients[patient_count] = *p;                       /* copy the whole struct */
    strcpy(patients[patient_count].status, "Outpatient");
    patients[patient_count].has_unpaid_bill = 0;
    patient_count++;

    snprintf(text, sizeof(text), "Registered patient %s", p->full_name);
    log_activity("register", p->id, 0, text);
    return 1;
}

/* Checks the "can this patient be deleted?" rules without deleting anything.
 * The UI calls this first, so it can ask "Are you sure?" only when removal is allowed. */
int can_remove_patient(int patient_id, char *msg)
{
    int index = find_patient(patient_id);

    if (index == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    if (strcmp(patients[index].status, "Admitted") == 0) {
        snprintf(msg, MSG_SIZE, "Cannot remove: the patient is currently admitted.");
        return 0;
    }
    if (patients[index].has_unpaid_bill || find_unpaid_bill(patient_id) != -1) {
        snprintf(msg, MSG_SIZE, "Cannot remove: the patient has an unpaid bill.");
        return 0;
    }
    return 1;
}

int remove_patient(int patient_id, char *msg)
{
    int index, i;
    char text[MSG_SIZE];

    if (!can_remove_patient(patient_id, msg)) {
        return 0;
    }
    index = find_patient(patient_id);
    snprintf(text, sizeof(text), "Removed patient %s", patients[index].full_name);
    for (i = index; i < patient_count - 1; i++) {       /* close the gap */
        patients[i] = patients[i + 1];
    }
    patient_count--;
    log_activity("remove", patient_id, 0, text);
    return 1;
}

/* ====================== Doctors ====================== */

int add_doctor(const Doctor *d, char *msg)
{
    int i;
    int any_day = 0;
    char text[MSG_SIZE];

    if (d->id <= 0) {
        snprintf(msg, MSG_SIZE, "Doctor ID must be a positive number.");
        return 0;
    }
    if (find_doctor(d->id) != -1) {
        snprintf(msg, MSG_SIZE, "Doctor ID %d already exists.", d->id);
        return 0;
    }
    if (is_blank(d->name)) {
        snprintf(msg, MSG_SIZE, "Doctor name cannot be empty.");
        return 0;
    }
    if (d->consultation_fee <= 0) {
        snprintf(msg, MSG_SIZE, "Consultation fee must be greater than 0.");
        return 0;
    }
    for (i = 0; i < 7; i++) {
        if (d->available_days[i]) any_day = 1;
    }
    if (!any_day) {
        snprintf(msg, MSG_SIZE, "Tick at least one available day.");
        return 0;
    }
    if (doctor_count >= MAX_DOCTORS) {
        snprintf(msg, MSG_SIZE, "The doctor list is full.");
        return 0;
    }

    doctors[doctor_count] = *d;
    doctor_count++;
    snprintf(text, sizeof(text), "Added doctor %s (%s)", d->name, d->specialisation);
    log_activity("doctor", 0, d->id, text);
    return 1;
}

int remove_doctor(int doctor_id, char *msg)
{
    int index = find_doctor(doctor_id);
    int i;
    char text[MSG_SIZE];

    if (index == -1) {
        snprintf(msg, MSG_SIZE, "Doctor ID %d does not exist.", doctor_id);
        return 0;
    }
    /* A doctor with Scheduled or Completed appointments is still needed
     * (for the booked slots and for the consultation fee in the bills). */
    for (i = 0; i < appointment_count; i++) {
        if (appointments[i].doctor_id == doctor_id &&
            strcmp(appointments[i].status, "Cancelled") != 0) {
            snprintf(msg, MSG_SIZE,
                     "Cannot remove: this doctor still has scheduled or completed appointments.");
            return 0;
        }
    }
    snprintf(text, sizeof(text), "Removed doctor %s", doctors[index].name);
    for (i = index; i < doctor_count - 1; i++) {
        doctors[i] = doctors[i + 1];
    }
    doctor_count--;
    log_activity("doctor", 0, doctor_id, text);
    return 1;
}

/* ====================== Appointments ====================== */

int schedule_appointment(int patient_id, int doctor_id, const char *date,
                         const char *slot, char *msg, int *new_id)
{
    int doctor_index, weekday, i, slot_ok = 0;
    char text[MSG_SIZE];

    if (find_patient(patient_id) == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    doctor_index = find_doctor(doctor_id);
    if (doctor_index == -1) {
        snprintf(msg, MSG_SIZE, "Doctor ID %d does not exist.", doctor_id);
        return 0;
    }
    if (!is_valid_date(date)) {
        snprintf(msg, MSG_SIZE, "Appointment date must be a real date in YYYY-MM-DD format.");
        return 0;
    }
    for (i = 0; i < NUM_SLOTS; i++) {
        if (strcmp(slot, time_slots[i]) == 0) slot_ok = 1;
    }
    if (!slot_ok) {
        snprintf(msg, MSG_SIZE, "Please choose a time slot between 08:00 and 17:00.");
        return 0;
    }

    /* Is the doctor working on that weekday? */
    weekday = day_of_week(date);
    if (!doctors[doctor_index].available_days[weekday]) {
        snprintf(msg, MSG_SIZE, "Doctor not available on %s", day_names[weekday]);
        return 0;
    }

    /* Is the slot already taken (cancelled bookings do not count)? */
    for (i = 0; i < appointment_count; i++) {
        if (appointments[i].doctor_id == doctor_id &&
            strcmp(appointments[i].date, date) == 0 &&
            strcmp(appointments[i].time_slot, slot) == 0 &&
            strcmp(appointments[i].status, "Cancelled") != 0) {
            snprintf(msg, MSG_SIZE, "Slot already booked");
            return 0;
        }
    }
    if (appointment_count >= MAX_APPOINTMENTS) {
        snprintf(msg, MSG_SIZE, "The appointment list is full.");
        return 0;
    }

    /* Appointments are never deleted, so count + 1 is always a new unique ID. */
    appointments[appointment_count].id = appointment_count + 1;
    appointments[appointment_count].patient_id = patient_id;
    appointments[appointment_count].doctor_id = doctor_id;
    snprintf(appointments[appointment_count].date, 11, "%s", date);
    snprintf(appointments[appointment_count].time_slot, 6, "%s", slot);
    strcpy(appointments[appointment_count].status, "Scheduled");
    *new_id = appointments[appointment_count].id;
    appointment_count++;

    snprintf(text, sizeof(text), "Appointment #%d on %s at %s", *new_id, date, slot);
    log_activity("appointment", patient_id, doctor_id, text);
    return 1;
}

int change_appointment_status(int appointment_id, const char *new_status, char *msg)
{
    int index = find_appointment(appointment_id);
    char text[MSG_SIZE];

    if (index == -1) {
        snprintf(msg, MSG_SIZE, "Appointment ID %d does not exist.", appointment_id);
        return 0;
    }
    if (strcmp(appointments[index].status, "Scheduled") != 0) {
        snprintf(msg, MSG_SIZE, "Only a Scheduled appointment can be changed (this one is %s).",
                 appointments[index].status);
        return 0;
    }
    strcpy(appointments[index].status, new_status);
    snprintf(text, sizeof(text), "Appointment #%d marked %s", appointment_id, new_status);
    log_activity("appointment", appointments[index].patient_id,
                 appointments[index].doctor_id, text);
    return 1;
}

/* ====================== Medical records ====================== */

int record_visit(int appointment_id, const char *symptoms,
                 const char *diagnosis, const Medicine meds[], int med_count,
                 const char *followup_date, char *msg)
{
    int index = find_appointment(appointment_id);
    int i;
    char text[MSG_SIZE];
    MedicalRecord *rec;

    if (index == -1) {
        snprintf(msg, MSG_SIZE, "Appointment ID %d does not exist.", appointment_id);
        return 0;
    }
    if (strcmp(appointments[index].status, "Completed") != 0) {
        snprintf(msg, MSG_SIZE, "A visit can only be recorded for a Completed appointment.");
        return 0;
    }
    for (i = 0; i < record_count; i++) {
        if (records[i].appointment_id == appointment_id) {
            snprintf(msg, MSG_SIZE, "A visit is already recorded for this appointment.");
            return 0;
        }
    }
    if (is_blank(diagnosis)) {
        snprintf(msg, MSG_SIZE, "Diagnosis cannot be empty.");
        return 0;
    }
    if (!is_valid_date(followup_date)) {
        snprintf(msg, MSG_SIZE, "Follow-up date must be a real date in YYYY-MM-DD format.");
        return 0;
    }
    if (strcmp(followup_date, appointments[index].date) <= 0) {
        snprintf(msg, MSG_SIZE, "Follow-up date must be later than the visit date (%s).",
                 appointments[index].date);
        return 0;
    }
    for (i = 0; i < med_count; i++) {
        if (is_blank(meds[i].dosage)) {
            snprintf(msg, MSG_SIZE, "Medicine \"%s\" needs a dosage.", meds[i].name);
            return 0;
        }
        if (meds[i].days <= 0) {
            snprintf(msg, MSG_SIZE, "Medicine \"%s\" needs a number of days above 0.", meds[i].name);
            return 0;
        }
    }
    if (record_count >= MAX_RECORDS) {
        snprintf(msg, MSG_SIZE, "The medical record list is full.");
        return 0;
    }

    rec = &records[record_count];
    memset(rec, 0, sizeof(MedicalRecord));
    rec->id = record_count + 1;
    rec->appointment_id = appointment_id;
    rec->patient_id = appointments[index].patient_id;
    snprintf(rec->visit_date, 11, "%s", appointments[index].date);
    snprintf(rec->symptoms, sizeof(rec->symptoms), "%s", symptoms);
    snprintf(rec->diagnosis, sizeof(rec->diagnosis), "%s", diagnosis);
    for (i = 0; i < med_count && i < MAX_MEDICINES; i++) {
        rec->medicines[i] = meds[i];
    }
    rec->medicine_count = (med_count > MAX_MEDICINES) ? MAX_MEDICINES : med_count;
    snprintf(rec->followup_date, 11, "%s", followup_date);
    record_count++;

    snprintf(text, sizeof(text), "Visit recorded: %s", diagnosis);
    log_activity("visit", rec->patient_id, appointments[index].doctor_id, text);
    return 1;
}

/* ====================== Admissions ====================== */

int admit_patient(int patient_id, int ward, int bed_number,
                  const char *admission_date, char *msg)
{
    int patient_index = find_patient(patient_id);
    int i;
    char text[MSG_SIZE];

    if (patient_index == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    if (strcmp(patients[patient_index].status, "Admitted") == 0) {
        snprintf(msg, MSG_SIZE, "This patient is already admitted.");
        return 0;
    }
    if (ward < 0 || ward >= NUM_WARDS) {
        snprintf(msg, MSG_SIZE, "Please choose a ward.");
        return 0;
    }
    if (bed_number < 1 || bed_number > BEDS_PER_WARD) {
        snprintf(msg, MSG_SIZE, "Bed number must be between 1 and %d.", BEDS_PER_WARD);
        return 0;
    }
    if (!is_valid_date(admission_date)) {
        snprintf(msg, MSG_SIZE, "Admission date must be a real date in YYYY-MM-DD format.");
        return 0;
    }
    /* Is somebody else already lying in this bed? */
    for (i = 0; i < admission_count; i++) {
        if (admissions[i].is_active && admissions[i].ward == ward &&
            admissions[i].bed_number == bed_number) {
            snprintf(msg, MSG_SIZE, "Bed %d in the %s ward is already occupied.",
                     bed_number, ward_names[ward]);
            return 0;
        }
    }
    if (admission_count >= MAX_ADMISSIONS) {
        snprintf(msg, MSG_SIZE, "The admission list is full.");
        return 0;
    }

    memset(&admissions[admission_count], 0, sizeof(Admission));
    admissions[admission_count].patient_id = patient_id;
    admissions[admission_count].ward = ward;
    admissions[admission_count].bed_number = bed_number;
    snprintf(admissions[admission_count].admission_date, 11, "%s", admission_date);
    admissions[admission_count].is_active = 1;
    admission_count++;

    strcpy(patients[patient_index].status, "Admitted");
    snprintf(text, sizeof(text), "Admitted to %s ward, bed %d", ward_names[ward], bed_number);
    log_activity("admit", patient_id, 0, text);
    return 1;
}

int discharge_patient(int patient_id, const char *discharge_date, char *msg)
{
    int patient_index = find_patient(patient_id);
    int adm;
    int days;
    char text[MSG_SIZE];

    if (patient_index == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    adm = find_active_admission(patient_id);
    if (adm == -1) {
        snprintf(msg, MSG_SIZE, "This patient is not currently admitted.");
        return 0;
    }
    if (!is_valid_date(discharge_date)) {
        snprintf(msg, MSG_SIZE, "Discharge date must be a real date in YYYY-MM-DD format.");
        return 0;
    }
    if (strcmp(discharge_date, admissions[adm].admission_date) < 0) {
        snprintf(msg, MSG_SIZE, "Discharge date cannot be before the admission date (%s).",
                 admissions[adm].admission_date);
        return 0;
    }

    days = days_between(admissions[adm].admission_date, discharge_date);
    if (days < 1) {
        days = 1;                                   /* minimum charge is 1 day */
    }
    snprintf(admissions[adm].discharge_date, 11, "%s", discharge_date);
    admissions[adm].days_stayed = days;
    admissions[adm].is_active = 0;                  /* this frees the bed */
    strcpy(patients[patient_index].status, "Discharged");

    snprintf(text, sizeof(text), "Discharged after %d day(s)", days);
    log_activity("discharge", patient_id, 0, text);
    return 1;
}

/* ====================== Billing ====================== */

/* Re-checks all bills of a patient and sets the "has_unpaid_bill" flag. */
static void refresh_unpaid_flag(int patient_id)
{
    int patient_index = find_patient(patient_id);
    if (patient_index != -1) {
        patients[patient_index].has_unpaid_bill =
            (find_unpaid_bill(patient_id) != -1) ? 1 : 0;
    }
}

static int insurance_percent(const char *insurance)
{
    if (strcmp(insurance, "Public") == 0)  return 50;
    if (strcmp(insurance, "Private") == 0) return 80;
    return 0;                                       /* "None" */
}

int generate_bill(int patient_id, double medicine_charges, double lab_charges,
                  char *msg, int *bill_index)
{
    int patient_index = find_patient(patient_id);
    int i, doctor_index, index;
    double consultation = 0, beds = 0, gross, covered;
    char text[MSG_SIZE];
    Bill *bill;

    if (patient_index == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    if (medicine_charges < 0 || lab_charges < 0) {
        snprintf(msg, MSG_SIZE, "Charges cannot be negative.");
        return 0;
    }
    if (strcmp(patients[patient_index].status, "Admitted") == 0) {
        snprintf(msg, MSG_SIZE, "Discharge the patient first so the bed days are known.");
        return 0;
    }

    /* Consultations: every Completed appointment costs the doctor's fee */
    for (i = 0; i < appointment_count; i++) {
        if (appointments[i].patient_id == patient_id &&
            strcmp(appointments[i].status, "Completed") == 0) {
            doctor_index = find_doctor(appointments[i].doctor_id);
            if (doctor_index != -1) {
                consultation += doctors[doctor_index].consultation_fee;
            }
        }
    }
    /* Bed charges: days stayed x the daily rate of the ward */
    for (i = 0; i < admission_count; i++) {
        if (admissions[i].patient_id == patient_id && !admissions[i].is_active) {
            beds += admissions[i].days_stayed * ward_rates[admissions[i].ward];
        }
    }

    gross = consultation + beds + medicine_charges + lab_charges;
    if (gross <= 0) {
        snprintf(msg, MSG_SIZE, "Nothing to bill: no completed appointments, stays or charges.");
        return 0;
    }
    covered = gross * insurance_percent(patients[patient_index].insurance) / 100.0;

    /* Re-use the patient's open (unpaid) bill if there is one, else add a new one */
    index = find_unpaid_bill(patient_id);
    if (index == -1) {
        if (bill_count >= MAX_BILLS) {
            snprintf(msg, MSG_SIZE, "The bill list is full.");
            return 0;
        }
        index = bill_count;
        bills[index].id = bill_count + 1;
        bill_count++;
    }
    bill = &bills[index];
    bill->patient_id = patient_id;
    bill->consultation_total = consultation;
    bill->bed_charges = beds;
    bill->medicine_charges = medicine_charges;
    bill->lab_charges = lab_charges;
    bill->gross_total = gross;
    bill->insurance_covered = covered;
    bill->discount_percent = 0;
    bill->discount_amount = 0;
    bill->discount_reason[0] = '\0';
    bill->net_payable = gross - covered;
    strcpy(bill->status, "Unpaid");

    patients[patient_index].has_unpaid_bill = 1;
    snprintf(text, sizeof(text), "Bill #%d generated, net payable %.0f", bill->id, bill->net_payable);
    log_activity("bill", patient_id, 0, text);
    *bill_index = index;
    return 1;
}

int set_bill_status(int bill_index, const char *new_status)
{
    char text[MSG_SIZE];

    if (bill_index < 0 || bill_index >= bill_count) return 0;
    strcpy(bills[bill_index].status, new_status);
    refresh_unpaid_flag(bills[bill_index].patient_id);
    snprintf(text, sizeof(text), "Bill #%d marked %s", bills[bill_index].id, new_status);
    log_activity("bill", bills[bill_index].patient_id, 0, text);
    return 1;
}

int apply_discount(int patient_id, int percent, const char *reason, char *msg)
{
    int index;
    double amount_after_insurance;
    char text[MSG_SIZE];
    Bill *bill;

    if (find_patient(patient_id) == -1) {
        snprintf(msg, MSG_SIZE, "Patient ID %d does not exist.", patient_id);
        return 0;
    }
    if (percent < 5 || percent > 20) {
        snprintf(msg, MSG_SIZE, "Discount must be between 5%% and 20%%. The bill was not changed.");
        return 0;
    }
    if (is_blank(reason)) {
        snprintf(msg, MSG_SIZE, "Please choose a discount reason.");
        return 0;
    }
    index = find_unpaid_bill(patient_id);
    if (index == -1) {
        snprintf(msg, MSG_SIZE, "This patient has no unpaid bill. Generate a bill first.");
        return 0;
    }

    bill = &bills[index];
    /* The discount is taken from what the patient has to pay after insurance.
     * We always start again from gross - insurance, so applying a second
     * discount replaces the first instead of stacking on top of it. */
    amount_after_insurance = bill->gross_total - bill->insurance_covered;
    bill->discount_percent = percent;
    bill->discount_amount = amount_after_insurance * percent / 100.0;
    snprintf(bill->discount_reason, sizeof(bill->discount_reason), "%s", reason);
    bill->net_payable = amount_after_insurance - bill->discount_amount;

    snprintf(msg, MSG_SIZE, "Discount of %d%% (%s) applied. New amount payable: %.0f RWF",
             percent, reason, bill->net_payable);
    snprintf(text, sizeof(text), "Discount %d%% (%s) on bill #%d", percent, reason, bill->id);
    log_activity("discount", patient_id, 0, text);
    return 1;
}

/* A small helper that adds one line of text to the end of a big buffer. */
static void add_line(char *buffer, int size, const char *line)
{
    strncat(buffer, line, (size_t)(size - (int)strlen(buffer) - 1));
}

void build_bill_text(int bill_index, char *buffer, int size)
{
    Bill *b = &bills[bill_index];
    int patient_index = find_patient(b->patient_id);
    char line[200];

    buffer[0] = '\0';
    add_line(buffer, size, "==========================================\n");
    snprintf(line, sizeof(line), "   CAREDESK HOSPITAL - BILL #%d\n", b->id);
    add_line(buffer, size, line);
    add_line(buffer, size, "==========================================\n");
    if (patient_index != -1) {
        snprintf(line, sizeof(line), "Patient   : %d - %s\n", b->patient_id, patients[patient_index].full_name);
        add_line(buffer, size, line);
        snprintf(line, sizeof(line), "Insurance : %s\n", patients[patient_index].insurance);
        add_line(buffer, size, line);
    } else {
        snprintf(line, sizeof(line), "Patient   : %d (removed)\n", b->patient_id);
        add_line(buffer, size, line);
    }
    add_line(buffer, size, "------------------------------------------\n");
    snprintf(line, sizeof(line), "Consultations      : %12.0f RWF\n", b->consultation_total);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Bed charges        : %12.0f RWF\n", b->bed_charges);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Medicines          : %12.0f RWF\n", b->medicine_charges);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Lab tests          : %12.0f RWF\n", b->lab_charges);
    add_line(buffer, size, line);
    add_line(buffer, size, "------------------------------------------\n");
    snprintf(line, sizeof(line), "Gross total        : %12.0f RWF\n", b->gross_total);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Insurance covered  : %12.0f RWF\n", b->insurance_covered);
    add_line(buffer, size, line);
    if (b->discount_percent > 0) {
        snprintf(line, sizeof(line), "Discount %2d%% (%s): %6.0f RWF\n",
                 b->discount_percent, b->discount_reason, b->discount_amount);
        add_line(buffer, size, line);
    } else {
        add_line(buffer, size, "Discount           :            0 RWF\n");
    }
    add_line(buffer, size, "------------------------------------------\n");
    snprintf(line, sizeof(line), "NET PAYABLE        : %12.0f RWF\n", b->net_payable);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Status             : %s\n", b->status);
    add_line(buffer, size, line);
    add_line(buffer, size, "==========================================\n");
}

/* ====================== Report ====================== */

void build_report_text(char *buffer, int size)
{
    char today[11], line[200];
    int outpatients = 0, admitted = 0, discharged = 0;
    int today_count = 0, month_count = 0;
    int per_doctor[MAX_DOCTORS];
    int occupied[NUM_WARDS];
    double paid = 0, unpaid = 0, insured = 0;
    int i, j, count, best, best_count;

    get_today(today);
    buffer[0] = '\0';

    /* ----- patients ----- */
    for (i = 0; i < patient_count; i++) {
        if (strcmp(patients[i].status, "Outpatient") == 0) outpatients++;
        else if (strcmp(patients[i].status, "Admitted") == 0) admitted++;
        else if (strcmp(patients[i].status, "Discharged") == 0) discharged++;
    }
    add_line(buffer, size, "======== CAREDESK HOSPITAL REPORT ========\n");
    snprintf(line, sizeof(line), "Generated on: %s\n\n", today);
    add_line(buffer, size, line);
    add_line(buffer, size, "--- PATIENTS ---\n");
    snprintf(line, sizeof(line), "Total patients : %d\n", patient_count);
    add_line(buffer, size, line);
    snprintf(line, sizeof(line), "Outpatient     : %d\nAdmitted       : %d\nDischarged     : %d\n\n",
             outpatients, admitted, discharged);
    add_line(buffer, size, line);

    /* ----- appointments (cancelled ones are not counted) ----- */
    for (i = 0; i < doctor_count; i++) per_doctor[i] = 0;
    for (i = 0; i < appointment_count; i++) {
        if (strcmp(appointments[i].status, "Cancelled") == 0) continue;
        if (strcmp(appointments[i].date, today) == 0) today_count++;
        if (strncmp(appointments[i].date, today, 7) == 0) month_count++;   /* same YYYY-MM */
        j = find_doctor(appointments[i].doctor_id);
        if (j != -1) per_doctor[j]++;
    }
    add_line(buffer, size, "--- APPOINTMENTS (not cancelled) ---\n");
    snprintf(line, sizeof(line), "Today      : %d\nThis month : %d\n", today_count, month_count);
    add_line(buffer, size, line);
    add_line(buffer, size, "Per doctor:\n");
    for (i = 0; i < doctor_count; i++) {
        snprintf(line, sizeof(line), "  Dr. %-25s : %d\n", doctors[i].name, per_doctor[i]);
        add_line(buffer, size, line);
    }
    add_line(buffer, size, "\n");

    /* ----- bed occupancy ----- */
    for (i = 0; i < NUM_WARDS; i++) occupied[i] = 0;
    for (i = 0; i < admission_count; i++) {
        if (admissions[i].is_active) occupied[admissions[i].ward]++;
    }
    add_line(buffer, size, "--- BED OCCUPANCY ---\n");
    for (i = 0; i < NUM_WARDS; i++) {
        snprintf(line, sizeof(line), "%-11s : %d/%d beds = %.1f%%\n", ward_names[i],
                 occupied[i], BEDS_PER_WARD, occupied[i] * 100.0 / BEDS_PER_WARD);
        add_line(buffer, size, line);
    }
    add_line(buffer, size, "\n");

    /* ----- money ----- */
    for (i = 0; i < bill_count; i++) {
        if (strcmp(bills[i].status, "Paid") == 0) paid += bills[i].net_payable;
        else unpaid += bills[i].net_payable;
        insured += bills[i].insurance_covered;
    }
    add_line(buffer, size, "--- MONEY (RWF) ---\n");
    snprintf(line, sizeof(line), "Revenue collected (Paid)  : %.0f\nOutstanding (Unpaid)      : %.0f\nCovered by insurance      : %.0f\n\n",
             paid, unpaid, insured);
    add_line(buffer, size, line);

    /* ----- most common diagnosis: count how often each one appears ----- */
    add_line(buffer, size, "--- HIGHLIGHTS ---\n");
    best = -1;
    best_count = 0;
    for (i = 0; i < record_count; i++) {
        count = 0;
        for (j = 0; j < record_count; j++) {
            if (strcmp(records[i].diagnosis, records[j].diagnosis) == 0) count++;
        }
        if (count > best_count) {
            best_count = count;
            best = i;
        }
    }
    if (best == -1) {
        add_line(buffer, size, "Most common diagnosis : (no records yet)\n");
    } else {
        snprintf(line, sizeof(line), "Most common diagnosis : %s (%d times)\n",
                 records[best].diagnosis, best_count);
        add_line(buffer, size, line);
    }

    /* ----- busiest doctor ----- */
    best = -1;
    best_count = 0;
    for (i = 0; i < doctor_count; i++) {
        if (per_doctor[i] > best_count) {
            best_count = per_doctor[i];
            best = i;
        }
    }
    if (best == -1) {
        add_line(buffer, size, "Busiest doctor         : (no appointments yet)\n");
    } else {
        snprintf(line, sizeof(line), "Busiest doctor         : Dr. %s (%d appointments)\n",
                 doctors[best].name, best_count);
        add_line(buffer, size, line);
    }
    add_line(buffer, size, "==========================================\n");
}

/* ====================== Login and user accounts ====================== */

int current_user_index = -1;                    /* -1 means nobody is logged in */

/* A simple "djb2" hash: the same text always gives the same number, but you
 * cannot easily get the password back from the number. This is good enough for
 * a student project; a real hospital system would use a strong, salted hash. */
unsigned int hash_password(const char *password)
{
    unsigned int hash = 5381;
    int i;

    for (i = 0; password[i] != '\0'; i++) {
        hash = hash * 33 + (unsigned char)password[i];
    }
    return hash;
}

static int find_user(const char *username)
{
    int i;
    for (i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) return i;
    }
    return -1;
}

/* On the very first run there are no users, so we create one account. */
void ensure_default_admin(void)
{
    if (user_count == 0) {
        memset(&users[0], 0, sizeof(User));
        strcpy(users[0].username, "admin");
        users[0].password_hash = hash_password("admin123");
        strcpy(users[0].role, "Admin");
        user_count = 1;
    }
}

int default_admin_unchanged(void)
{
    return user_count > 0 && strcmp(users[0].username, "admin") == 0 &&
           users[0].password_hash == hash_password("admin123");
}

int login_user(const char *username, const char *password, char *msg)
{
    int index = find_user(username);
    char text[MSG_SIZE];

    /* Same message for "no such user" and "wrong password", so nobody can
     * use the error to find out which usernames exist. */
    if (index == -1 || users[index].password_hash != hash_password(password)) {
        snprintf(msg, MSG_SIZE, "Wrong username or password.");
        snprintf(text, sizeof(text), "Failed login attempt for user '%s'", username);
        log_activity("login", 0, 0, text);
        return 0;
    }
    current_user_index = index;
    snprintf(text, sizeof(text), "User '%s' logged in (%s)", username, users[index].role);
    log_activity("login", 0, 0, text);
    return 1;
}

void log_logout(void)
{
    char text[MSG_SIZE];
    if (current_user_index >= 0 && current_user_index < user_count) {
        snprintf(text, sizeof(text), "User '%s' logged out", users[current_user_index].username);
        log_activity("logout", 0, 0, text);
    }
}

int change_password(const char *old_password, const char *new_password,
                    const char *confirm_password, char *msg)
{
    if (current_user_index < 0 || current_user_index >= user_count) {
        snprintf(msg, MSG_SIZE, "Nobody is logged in.");
        return 0;
    }
    if (users[current_user_index].password_hash != hash_password(old_password)) {
        snprintf(msg, MSG_SIZE, "The current password is wrong.");
        return 0;
    }
    if (strlen(new_password) < 4) {
        snprintf(msg, MSG_SIZE, "The new password must have at least 4 characters.");
        return 0;
    }
    if (strcmp(new_password, confirm_password) != 0) {
        snprintf(msg, MSG_SIZE, "The new password and the confirmation do not match.");
        return 0;
    }
    users[current_user_index].password_hash = hash_password(new_password);
    log_activity("login", 0, 0, "Password changed");
    return 1;
}

int add_user(const char *username, const char *password, const char *role, char *msg)
{
    int i;
    char text[MSG_SIZE];

    if (current_user_index < 0 || strcmp(users[current_user_index].role, "Admin") != 0) {
        snprintf(msg, MSG_SIZE, "Only an Admin can add users.");
        return 0;
    }
    if (is_blank(username) || strlen(username) > 20) {
        snprintf(msg, MSG_SIZE, "Username must be 1 to 20 characters.");
        return 0;
    }
    for (i = 0; username[i] != '\0'; i++) {
        if (username[i] == ' ') {
            snprintf(msg, MSG_SIZE, "Username cannot contain spaces.");
            return 0;
        }
    }
    if (find_user(username) != -1) {
        snprintf(msg, MSG_SIZE, "Username '%s' already exists.", username);
        return 0;
    }
    if (strlen(password) < 4) {
        snprintf(msg, MSG_SIZE, "The password must have at least 4 characters.");
        return 0;
    }
    if (user_count >= MAX_USERS) {
        snprintf(msg, MSG_SIZE, "The user list is full.");
        return 0;
    }
    memset(&users[user_count], 0, sizeof(User));
    snprintf(users[user_count].username, sizeof(users[user_count].username), "%s", username);
    users[user_count].password_hash = hash_password(password);
    snprintf(users[user_count].role, sizeof(users[user_count].role), "%s", role);
    user_count++;

    snprintf(text, sizeof(text), "Added user '%s' (%s)", username, role);
    log_activity("login", 0, 0, text);
    return 1;
}

/* ====================== Files ====================== */

int save_text_file(const char *filename, const char *text)
{
    FILE *file = fopen(filename, "w");
    if (file == NULL) return 0;
    fputs(text, file);
    fclose(file);
    return 1;
}
