/* storage.c - owns the global arrays and saves/loads them.
 *
 * File format (very simple): first an int with the number of items,
 * then the items themselves, written exactly as they are in memory.
 */
#include <stdio.h>
#include "models.h"
#include "storage.h"

/* The real global arrays (models.h only declared them with "extern"). */
Patient       patients[MAX_PATIENTS];        int patient_count = 0;
Doctor        doctors[MAX_DOCTORS];          int doctor_count = 0;
Appointment   appointments[MAX_APPOINTMENTS]; int appointment_count = 0;
MedicalRecord records[MAX_RECORDS];          int record_count = 0;
Admission     admissions[MAX_ADMISSIONS];    int admission_count = 0;
Bill          bills[MAX_BILLS];              int bill_count = 0;
HistoryEntry  history[MAX_HISTORY];          int history_count = 0;
User          users[MAX_USERS];              int user_count = 0;

/* Writes one array to one file. Returns 1 on success, 0 on failure. */
static int save_array(const char *filename, const void *array,
                      size_t item_size, int count)
{
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        return 0;
    }
    fwrite(&count, sizeof(int), 1, file);       /* how many items follow */
    fwrite(array, item_size, (size_t)count, file);
    fclose(file);
    return 1;
}

/* Reads one array from one file. If the file is missing (first run) or
 * damaged, the counter is set to 0 so the program starts with an empty list. */
static int load_array(const char *filename, void *array, size_t item_size,
                      int max_items, int *count)
{
    int stored = 0;
    FILE *file = fopen(filename, "rb");

    *count = 0;
    if (file == NULL) {
        return 0;                               /* first run: nothing to load */
    }
    if (fread(&stored, sizeof(int), 1, file) != 1 ||
        stored < 0 || stored > max_items) {
        fclose(file);
        return 0;                               /* file is damaged */
    }
    if (fread(array, item_size, (size_t)stored, file) != (size_t)stored) {
        fclose(file);
        return 0;
    }
    fclose(file);
    *count = stored;
    return 1;
}

void load_all_data(void)
{
    load_array("patients.dat",     patients,     sizeof(Patient),       MAX_PATIENTS,     &patient_count);
    load_array("doctors.dat",      doctors,      sizeof(Doctor),        MAX_DOCTORS,      &doctor_count);
    load_array("appointments.dat", appointments, sizeof(Appointment),   MAX_APPOINTMENTS, &appointment_count);
    load_array("records.dat",      records,      sizeof(MedicalRecord), MAX_RECORDS,      &record_count);
    load_array("admissions.dat",   admissions,   sizeof(Admission),     MAX_ADMISSIONS,   &admission_count);
    load_array("bills.dat",        bills,        sizeof(Bill),          MAX_BILLS,        &bill_count);
    load_array("history.dat",      history,      sizeof(HistoryEntry),  MAX_HISTORY,      &history_count);
    load_array("users.dat",        users,        sizeof(User),          MAX_USERS,        &user_count);
}

void save_all_data(void)
{
    save_array("patients.dat",     patients,     sizeof(Patient),       patient_count);
    save_array("doctors.dat",      doctors,      sizeof(Doctor),        doctor_count);
    save_array("appointments.dat", appointments, sizeof(Appointment),   appointment_count);
    save_array("records.dat",      records,      sizeof(MedicalRecord), record_count);
    save_array("admissions.dat",   admissions,   sizeof(Admission),     admission_count);
    save_array("bills.dat",        bills,        sizeof(Bill),          bill_count);
    save_array("history.dat",      history,      sizeof(HistoryEntry),  history_count);
    save_array("users.dat",        users,        sizeof(User),          user_count);
}
