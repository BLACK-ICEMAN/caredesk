/* validation.h - small helper functions that check text, dates and numbers.
 * None of them use GTK, so they are easy to test and to explain. */
#ifndef VALIDATION_H
#define VALIDATION_H

int  is_blank(const char *text);              /* 1 if empty or only spaces      */
int  is_all_digits(const char *text);         /* 1 if non-empty and only 0-9    */
int  has_real_text(const char *text);         /* 0 for "", "none", "no", "-"... */
void trim_text(char *text);                   /* remove spaces at both ends     */

int  is_valid_date(const char *date);         /* "YYYY-MM-DD" and a real date   */
void get_today(char *out);                    /* out needs 11 chars             */
void get_timestamp(char *out);                /* out needs 20 chars             */
int  is_future_date(const char *date);        /* 1 if date is after today       */
int  day_of_week(const char *date);           /* 0 = Monday ... 6 = Sunday      */
int  calculate_age(const char *dob);          /* age in whole years             */
int  days_between(const char *from, const char *to);
void date_plus_days(int offset_days, char *out);  /* today + offset (negative = past); out needs 11 chars */

#endif
