/* seed.c - demo data for presentations and marking.
 *
 * Important idea: we do NOT write directly into the arrays. We call the same
 * functions the buttons call (add_patient, schedule_appointment, generate_bill,
 * ...). So the demo data obeys every rule and also appears in the Activity History.
 * Dates are calculated from today, so the Report always has "today" figures. */
#include <stdio.h>
#include <string.h>
#include "seed.h"
#include "models.h"
#include "logic.h"
#include "validation.h"

/* days: seven characters for Mon..Sun, '1' = works that day, '0' = does not */
static void seed_doctor(int id, const char *name, const char *specialisation,
                        double fee, const char *days)
{
    Doctor d;
    char msg[MSG_SIZE];
    int i;

    memset(&d, 0, sizeof(Doctor));
    d.id = id;
    snprintf(d.name, sizeof(d.name), "%s", name);
    snprintf(d.specialisation, sizeof(d.specialisation), "%s", specialisation);
    d.consultation_fee = fee;
    for (i = 0; i < 7; i++) {
        d.available_days[i] = (days[i] == '1') ? 1 : 0;
    }
    add_doctor(&d, msg);
}

static void seed_patient(int id, const char *name, const char *dob, const char *gender,
                         const char *phone, const char *address, const char *blood,
                         const char *allergies, const char *emergency, const char *insurance)
{
    Patient p;
    char msg[MSG_SIZE];

    memset(&p, 0, sizeof(Patient));
    p.id = id;
    snprintf(p.full_name, sizeof(p.full_name), "%s", name);
    snprintf(p.dob, sizeof(p.dob), "%s", dob);
    snprintf(p.gender, sizeof(p.gender), "%s", gender);
    snprintf(p.phone, sizeof(p.phone), "%s", phone);
    snprintf(p.address, sizeof(p.address), "%s", address);
    snprintf(p.blood_group, sizeof(p.blood_group), "%s", blood);
    snprintf(p.allergies, sizeof(p.allergies), "%s", allergies);
    snprintf(p.emergency_contact, sizeof(p.emergency_contact), "%s", emergency);
    snprintf(p.insurance, sizeof(p.insurance), "%s", insurance);
    add_patient(&p, msg);
}

/* Books an appointment "days_ago" days before today (negative = in the future).
 * If the doctor does not work that day, we move to the next day further from
 * today until we find a working day. If the slot is taken we try the next one.
 * final_status: "Scheduled", "Completed" or "Cancelled". Returns the new ID. */
static int seed_appointment(int patient_id, int doctor_id, int days_ago,
                            int first_slot, const char *final_status)
{
    int doctor_index = find_doctor(doctor_id);
    int step = (days_ago > 0) ? 1 : -1;
    int tries, slot, new_id = 0;
    char date[11], msg[MSG_SIZE];

    if (doctor_index == -1) return 0;
    for (tries = 0; tries < 14; tries++) {
        date_plus_days(-days_ago, date);
        if (doctors[doctor_index].available_days[day_of_week(date)]) {
            for (slot = 0; slot < NUM_SLOTS; slot++) {
                if (schedule_appointment(patient_id, doctor_id, date,
                                         time_slots[(first_slot + slot) % NUM_SLOTS],
                                         msg, &new_id)) {
                    if (strcmp(final_status, "Scheduled") != 0) {
                        change_appointment_status(new_id, final_status, msg);
                    }
                    return new_id;
                }
            }
        }
        days_ago += step;
    }
    return 0;
}

/* Records the medical visit of a Completed appointment (one medicine, or none). */
static void seed_visit(int appointment_id, const char *symptoms, const char *diagnosis,
                       const char *medicine, const char *dosage, int days)
{
    Medicine meds[1];
    int count = 0;
    char followup[11], msg[MSG_SIZE];

    if (appointment_id == 0) return;
    memset(meds, 0, sizeof(meds));
    if (medicine[0] != '\0') {
        snprintf(meds[0].name, sizeof(meds[0].name), "%s", medicine);
        snprintf(meds[0].dosage, sizeof(meds[0].dosage), "%s", dosage);
        meds[0].days = days;
        count = 1;
    }
    date_plus_days(14, followup);               /* follow-up in two weeks */
    record_visit(appointment_id, symptoms, diagnosis, meds, count, followup, msg);
}

/* Creates a bill and sets it Paid or Unpaid. discount_percent 0 = no discount. */
static void seed_bill(int patient_id, double medicine, double lab, int discount_percent,
                      const char *discount_reason, const char *final_status)
{
    int bill_index;
    char msg[MSG_SIZE];

    if (!generate_bill(patient_id, medicine, lab, msg, &bill_index)) return;
    if (discount_percent > 0) {
        apply_discount(patient_id, discount_percent, discount_reason, msg);
    }
    if (strcmp(final_status, "Paid") == 0) {
        set_bill_status(bill_index, "Paid");
    }
}

int load_demo_data(char *msg)
{
    int a;
    char from[11], to[11];

    if (current_user_index < 0 || strcmp(users[current_user_index].role, "Admin") != 0) {
        snprintf(msg, MSG_SIZE, "Only an Admin can load the demo data.");
        return 0;
    }
    if (patient_count > 0 || doctor_count > 0) {
        snprintf(msg, MSG_SIZE,
                 "Demo data can only be loaded into an empty system. To start fresh, close the "
                 "program and delete the .dat files except users.dat.");
        return 0;
    }

    /* ----- 5 doctors (days: Mon Tue Wed Thu Fri Sat Sun) ----- */
    seed_doctor(1, "Jean Claude Habimana", "General",     10000, "1111111");
    seed_doctor(2, "Aline Uwimana",        "Paediatrics", 15000, "1010100");
    seed_doctor(3, "Patrick Nkurunziza",   "Surgery",     30000, "0101000");
    seed_doctor(4, "Grace Mukamana",       "Cardiology",  25000, "1111000");
    seed_doctor(5, "Eric Niyonzima",       "Dermatology", 20000, "0010110");

    /* ----- 10 patients ----- */
    seed_patient(1001, "Alice Uwase",         "1990-05-10", "Female", "0788123456", "Kimironko, Kigali",  "O+",      "Penicillin",  "Jean Uwase 0788000111",     "Private");
    seed_patient(1002, "Eric Mugisha",        "1985-11-02", "Male",   "0722456789", "Remera, Kigali",     "A+",      "None",        "Marie Mugisha 0722000222",  "Public");
    seed_patient(1003, "Diane Ingabire",      "2016-03-21", "Female", "0788765432", "Nyamirambo, Kigali", "B+",      "Peanuts",     "Paul Ingabire 0788000333",  "Public");
    seed_patient(1004, "Samuel Habyarimana",  "1958-07-15", "Male",   "0735111222", "Kicukiro, Kigali",   "AB+",     "None",        "Rose Habyarimana 0735000444", "Public");
    seed_patient(1005, "Claudine Mukamana",   "1995-09-30", "Female", "0788333444", "Gasabo, Kigali",     "O-",      "None",        "David Mukamana 0788000555", "Private");
    seed_patient(1006, "Joseph Niyonsenga",   "1972-01-08", "Male",   "0722777888", "Huye",               "A-",      "Sulfa drugs", "Anita Niyonsenga 0722000666", "Public");
    seed_patient(1007, "Aline Uwera",         "2001-12-12", "Female", "0788555666", "Musanze",            "B-",      "None",        "Pierre Uwera 0788000777",   "None");
    seed_patient(1008, "Patrick Ndayisaba",   "1949-04-25", "Male",   "0735999000", "Rubavu",             "O+",      "Aspirin",     "Chantal Ndayisaba 0735000888", "Public");
    seed_patient(1009, "Grace Uwimana",       "2010-06-18", "Female", "0788222333", "Kacyiru, Kigali",    "A+",      "None",        "Joy Uwimana 0788000999",    "Private");
    seed_patient(1010, "Moses Kamanzi",       "1988-02-14", "Male",   "0722333444", "Nyagatare",          "Unknown", "None",        "Ruth Kamanzi 0722001010",   "None");

    /* ----- completed visits in the past, with medical records ----- */
    a = seed_appointment(1001, 1, 20, 0, "Completed");
    seed_visit(a, "Fever, headache, chills", "Malaria", "Artemether", "80mg twice daily", 3);
    a = seed_appointment(1002, 1, 18, 1, "Completed");
    seed_visit(a, "Cough, chest pain", "Pneumonia", "Amoxicillin", "500mg 3 times daily", 7);
    a = seed_appointment(1003, 2, 15, 2, "Completed");
    seed_visit(a, "Fever, vomiting", "Malaria", "Artemether", "20mg twice daily", 3);
    a = seed_appointment(1004, 4, 14, 3, "Completed");
    seed_visit(a, "Chest pain, dizziness", "Hypertension", "Amlodipine", "5mg once daily", 30);
    a = seed_appointment(1006, 4, 10, 4, "Completed");
    seed_visit(a, "Headache, blurred vision", "Hypertension", "Enalapril", "10mg once daily", 30);
    a = seed_appointment(1005, 1, 12, 5, "Completed");
    seed_visit(a, "Abdominal pain, fever", "Typhoid", "Ciprofloxacin", "500mg twice daily", 7);
    a = seed_appointment(1007, 5, 9, 6, "Completed");
    seed_visit(a, "Itchy skin rash", "Skin allergy", "Cetirizine", "10mg once daily", 5);
    a = seed_appointment(1008, 3, 5, 7, "Completed");
    seed_visit(a, "Severe lower abdominal pain", "Appendicitis", "Ceftriaxone", "1g once daily", 5);
    a = seed_appointment(1009, 2, 7, 8, "Completed");
    seed_visit(a, "Fever, headache", "Malaria", "Artemether", "40mg twice daily", 3);
    a = seed_appointment(1010, 1, 3, 9, "Completed");
    seed_visit(a, "Dry cough, tiredness", "Pneumonia", "Amoxicillin", "500mg 3 times daily", 7);

    /* ----- today, cancelled and future appointments ----- */
    a = seed_appointment(1001, 1, 0, 3, "Completed");                  /* follow-up today */
    seed_visit(a, "Follow-up: feels better", "Recovered - no medication needed", "", "", 0);
    seed_appointment(1002, 1, 0, 5, "Scheduled");                      /* today, still waiting */
    seed_appointment(1009, 2, 4, 1, "Cancelled");                      /* patient cancelled */
    seed_appointment(1006, 4, -2, 2, "Scheduled");                     /* future */
    seed_appointment(1007, 5, -3, 4, "Scheduled");
    seed_appointment(1010, 3, -5, 6, "Scheduled");

    /* ----- hospital stays ----- */
    date_plus_days(-10, from);  date_plus_days(-6, to);
    admit_patient(1004, 0, 5, from, msg);                              /* General, 4 days */
    discharge_patient(1004, to, msg);
    date_plus_days(-7, from);   date_plus_days(-3, to);
    admit_patient(1005, 2, 4, from, msg);                              /* Maternity, 4 days */
    discharge_patient(1005, to, msg);
    date_plus_days(-4, from);
    admit_patient(1008, 1, 2, from, msg);                              /* ICU, still admitted */
    date_plus_days(-2, from);
    admit_patient(1003, 3, 1, from, msg);                              /* Paediatric, still admitted */

    /* ----- bills: paid, unpaid, with and without discount ----- */
    seed_bill(1004, 15000, 10000, 10, "Senior citizen", "Unpaid");     /* bold row */
    seed_bill(1005, 20000, 30000, 0,  "",               "Paid");
    seed_bill(1001, 6000,  5000,  0,  "",               "Unpaid");
    seed_bill(1002, 3000,  0,     0,  "",               "Paid");
    seed_bill(1010, 4000,  0,     5,  "Staff",          "Unpaid");

    /* ----- a Staff account so the teacher can try a second login ----- */
    add_user("nurse", "nurse123", "Staff", msg);

    snprintf(msg, MSG_SIZE,
             "Demo data loaded: %d doctors, %d patients, %d appointments, %d medical records, "
             "%d admissions and %d bills.\n\nExtra login: nurse / nurse123 (Staff).",
             doctor_count, patient_count, appointment_count, record_count,
             admission_count, bill_count);
    return 1;
}
