/* ui.c - the GTK 3 graphical interface.
 *
 * How to read this file:
 *   1. Widgets we need to remember are declared as static globals.
 *   2. Small helper functions (dialogs, reading text boxes, building tables).
 *   3. "refresh_..." functions that copy our arrays into the on-screen tables.
 *   4. One "on_..._clicked" function per button (these call logic.c).
 *   5. One "build_..._tab" function per tab, and create_main_window() at the end.
 *
 * The rules (validation, calculations) are NOT here - they are in logic.c.
 * The UI only: reads the boxes -> calls a logic function -> shows the result.
 */
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"
#include "models.h"
#include "logic.h"
#include "validation.h"
#include "storage.h"
#include "seed.h"

#define RESPONSE_PAID    1
#define RESPONSE_UNPAID  2
#define RESPONSE_EXPORT  3

static GtkWidget *main_window;

/* Patients tab */
static GtkWidget *pat_id_entry, *pat_name_entry, *pat_dob_entry, *pat_gender_combo;
static GtkWidget *pat_phone_entry, *pat_address_entry, *pat_blood_combo;
static GtkWidget *pat_allergy_entry, *pat_emergency_entry, *pat_insurance_combo;
static GtkWidget *pat_remove_entry, *patient_tree;
static GtkListStore *patient_store;

/* Doctors tab */
static GtkWidget *doc_id_entry, *doc_name_entry, *doc_spec_combo, *doc_fee_entry;
static GtkWidget *doc_day_checks[7];
static GtkWidget *doctor_tree;
static GtkListStore *doctor_store;

/* Appointments tab */
static GtkWidget *app_patient_entry, *app_doctor_entry, *app_date_entry, *app_slot_combo;
static GtkWidget *appointment_tree;
static GtkListStore *appointment_store;

/* Medical records tab */
static GtkWidget *rec_appointment_entry, *rec_symptoms_entry, *rec_diagnosis_entry;
static GtkWidget *rec_med_name[MAX_MEDICINES], *rec_med_dosage[MAX_MEDICINES], *rec_med_days[MAX_MEDICINES];
static GtkWidget *rec_followup_entry, *rec_history_patient_entry;
static GtkListStore *record_store;

/* Admissions tab */
static GtkWidget *adm_patient_entry, *adm_ward_combo, *adm_bed_spin, *adm_date_entry;
static GtkWidget *dis_patient_entry, *dis_date_entry;
static GtkListStore *admission_store;

/* Billing tab */
static GtkWidget *bill_patient_entry, *bill_medicine_entry, *bill_lab_entry;
static GtkWidget *disc_patient_entry, *disc_percent_entry, *disc_reason_combo;
static GtkWidget *bill_tree;
static GtkListStore *bill_store;

/* History tab */
static GtkWidget *hist_patient_entry, *hist_doctor_entry, *hist_date_entry;
static GtkListStore *history_store;

/* ====================================================================
 *  PART 1 - SMALL HELPER FUNCTIONS
 * ==================================================================== */

/* Pop-up message. type = GTK_MESSAGE_INFO or GTK_MESSAGE_ERROR */
static void show_message_on(GtkWindow *parent, GtkMessageType type, const char *text)
{
    GtkWidget *dialog = gtk_message_dialog_new(parent, GTK_DIALOG_MODAL, type,
                                               GTK_BUTTONS_OK, "%s", text);
    gtk_window_set_title(GTK_WINDOW(dialog),
                         type == GTK_MESSAGE_ERROR ? "Please check" : "CareDesk");
    gtk_dialog_run(GTK_DIALOG(dialog));     /* waits until OK is clicked */
    gtk_widget_destroy(dialog);
}

static void show_message(GtkMessageType type, const char *text)
{
    show_message_on(GTK_WINDOW(main_window), type, text);
}

/* Yes/No question. Returns 1 for Yes, 0 for No. */
static int ask_yes_no(const char *text)
{
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window), GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
                                               "%s", text);
    int answer = gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
    return answer == GTK_RESPONSE_YES;
}

/* Copies the text of an entry box into "dest" with spaces trimmed. */
static void read_entry(GtkWidget *entry, char *dest, int size)
{
    snprintf(dest, (size_t)size, "%s", gtk_entry_get_text(GTK_ENTRY(entry)));
    trim_text(dest);
}

/* Copies the chosen item of a drop-down list into "dest". */
static void read_combo(GtkWidget *combo, char *dest, int size)
{
    char *chosen = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo));
    if (chosen == NULL) {
        dest[0] = '\0';
    } else {
        snprintf(dest, (size_t)size, "%s", chosen);
        g_free(chosen);                     /* GTK gave us a copy: we must free it */
    }
}

/* Reads a whole number from an entry. Shows an error and returns 0 if it is not one. */
static int read_int_field(GtkWidget *entry, const char *field_name, int *value)
{
    char text[40];
    char msg[MSG_SIZE];

    read_entry(entry, text, sizeof(text));
    if (!is_all_digits(text) || strlen(text) > 9) {
        snprintf(msg, sizeof(msg), "%s must be a whole number (digits only).", field_name);
        show_message(GTK_MESSAGE_ERROR, msg);
        return 0;
    }
    *value = atoi(text);
    return 1;
}

/* Reads a decimal number. If allow_blank is 1 an empty box counts as 0. */
static int read_double_field(GtkWidget *entry, const char *field_name,
                             double *value, int allow_blank)
{
    char text[60];
    char msg[MSG_SIZE];
    char *end_of_number;

    read_entry(entry, text, sizeof(text));
    if (text[0] == '\0' && allow_blank) {
        *value = 0;
        return 1;
    }
    *value = strtod(text, &end_of_number);
    if (text[0] == '\0' || *end_of_number != '\0') {
        snprintf(msg, sizeof(msg), "%s must be a number.", field_name);
        show_message(GTK_MESSAGE_ERROR, msg);
        return 0;
    }
    return 1;
}

static GtkWidget *make_entry(const char *placeholder, int width)
{
    GtkWidget *entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), placeholder);
    gtk_entry_set_width_chars(GTK_ENTRY(entry), width);
    return entry;
}

static GtkWidget *make_date_entry(int fill_with_today)
{
    GtkWidget *entry = make_entry("YYYY-MM-DD", 12);
    char today[11];
    if (fill_with_today) {
        get_today(today);
        gtk_entry_set_text(GTK_ENTRY(entry), today);
    }
    return entry;
}

static GtkWidget *make_combo(const char *items[], int count)
{
    GtkWidget *combo = gtk_combo_box_text_new();
    int i;
    for (i = 0; i < count; i++) {
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), items[i]);
    }
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo), 0);
    return combo;
}

/* style_class is a CSS class name from the stylesheet: "primary" or "danger" */
static GtkWidget *make_button(const char *label, const char *style_class,
                              GCallback on_click)
{
    GtkWidget *button = gtk_button_new_with_label(label);
    gtk_style_context_add_class(gtk_widget_get_style_context(button), style_class);
    g_signal_connect(button, "clicked", on_click, NULL);
    return button;
}

/* Puts "label: widget" into a grid. column_pair 0 = left pair, 1 = next pair... */
static void add_form_row(GtkWidget *grid, int row, int column_pair,
                         const char *label_text, GtkWidget *widget)
{
    GtkWidget *label = gtk_label_new(label_text);
    gtk_widget_set_halign(label, GTK_ALIGN_END);
    gtk_grid_attach(GTK_GRID(grid), label, column_pair * 2, row, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), widget, column_pair * 2 + 1, row, 1, 1);
}

static GtkWidget *make_grid(void)
{
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 6);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 8);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 10);
    return grid;
}

/* A titled box around a form */
static GtkWidget *make_section(const char *title, GtkWidget *content)
{
    GtkWidget *frame = gtk_frame_new(title);
    gtk_container_add(GTK_CONTAINER(frame), content);
    return frame;
}

/* A list store where every visible column is text. If with_style is 1, two
 * hidden columns are added after them: the text colour and the font weight. */
static GtkListStore *make_store(int text_columns, int with_style)
{
    GType types[16];
    int i, total = text_columns;

    for (i = 0; i < text_columns; i++) {
        types[i] = G_TYPE_STRING;
    }
    if (with_style) {
        types[total] = G_TYPE_STRING;       /* colour, e.g. "red"           */
        types[total + 1] = G_TYPE_INT;      /* weight, 400 normal / 700 bold */
        total += 2;
    }
    return gtk_list_store_newv(total, types);
}

/* Builds a table (GtkTreeView) inside a scrolled window. */
static GtkWidget *make_table(GtkListStore *store, const char *titles[],
                             int text_columns, int with_style, GtkWidget **tree_out)
{
    GtkWidget *tree = gtk_tree_view_new_with_model(GTK_TREE_MODEL(store));
    GtkWidget *scrolled = gtk_scrolled_window_new(NULL, NULL);
    int i;

    for (i = 0; i < text_columns; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *column =
            gtk_tree_view_column_new_with_attributes(titles[i], renderer, "text", i, NULL);
        if (with_style) {
            gtk_tree_view_column_add_attribute(column, renderer, "foreground", text_columns);
            gtk_tree_view_column_add_attribute(column, renderer, "weight", text_columns + 1);
        }
        gtk_tree_view_column_set_resizable(column, TRUE);
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree), column);
    }
    gtk_tree_view_set_grid_lines(GTK_TREE_VIEW(tree), GTK_TREE_VIEW_GRID_LINES_HORIZONTAL);
    gtk_container_add(GTK_CONTAINER(scrolled), tree);
    gtk_widget_set_vexpand(scrolled, TRUE);
    if (tree_out != NULL) {
        *tree_out = tree;
    }
    return scrolled;
}

/* Returns the ID (first column) of the selected table row, or -1 if none. */
static int get_selected_id(GtkWidget *tree)
{
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;
    char *id_text;
    int id;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        return -1;
    }
    gtk_tree_model_get(model, &iter, 0, &id_text, -1);
    id = atoi(id_text);
    g_free(id_text);
    return id;
}

/* A read-only, scrollable, fixed-width text area. */
static GtkWidget *make_text_area(GtkTextBuffer **buffer_out, int width, int height)
{
    GtkWidget *text_view = gtk_text_view_new();
    GtkWidget *scrolled = gtk_scrolled_window_new(NULL, NULL);

    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    gtk_text_view_set_monospace(GTK_TEXT_VIEW(text_view), TRUE);
    gtk_text_view_set_left_margin(GTK_TEXT_VIEW(text_view), 10);
    gtk_container_add(GTK_CONTAINER(scrolled), text_view);
    gtk_widget_set_size_request(scrolled, width, height);
    *buffer_out = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    return scrolled;
}

/* ====================================================================
 *  PART 2 - REFRESH FUNCTIONS (arrays -> tables on screen)
 * ==================================================================== */

static void refresh_patients_table(void)
{
    int i;
    GtkTreeIter iter;
    char id_text[16], age_text[16];
    const char *color;
    int weight;

    gtk_list_store_clear(patient_store);
    for (i = 0; i < patient_count; i++) {
        snprintf(id_text, sizeof(id_text), "%d", patients[i].id);
        snprintf(age_text, sizeof(age_text), "%d", calculate_age(patients[i].dob));

        /* Row styling rules: Admitted = red, allergies = orange, unpaid = bold */
        color = "#202020";                                  /* normal dark text */
        if (strcmp(patients[i].status, "Admitted") == 0) {
            color = "red";
        } else if (has_real_text(patients[i].allergies)) {
            color = "#E67E00";                              /* orange */
        }
        weight = patients[i].has_unpaid_bill ? PANGO_WEIGHT_BOLD : PANGO_WEIGHT_NORMAL;

        gtk_list_store_append(patient_store, &iter);
        gtk_list_store_set(patient_store, &iter,
                           0, id_text, 1, patients[i].full_name, 2, age_text,
                           3, patients[i].gender, 4, patients[i].phone,
                           5, patients[i].blood_group, 6, patients[i].insurance,
                           7, patients[i].status, 8, color, 9, weight, -1);
    }
}

static void refresh_doctors_table(void)
{
    int i, d;
    GtkTreeIter iter;
    char id_text[16], fee_text[32], days_text[64];

    gtk_list_store_clear(doctor_store);
    for (i = 0; i < doctor_count; i++) {
        snprintf(id_text, sizeof(id_text), "%d", doctors[i].id);
        snprintf(fee_text, sizeof(fee_text), "%.0f", doctors[i].consultation_fee);
        days_text[0] = '\0';
        for (d = 0; d < 7; d++) {
            if (doctors[i].available_days[d]) {
                strncat(days_text, day_names[d], 3);        /* "Mon", "Tue", ... */
                strcat(days_text, " ");
            }
        }
        gtk_list_store_append(doctor_store, &iter);
        gtk_list_store_set(doctor_store, &iter, 0, id_text, 1, doctors[i].name,
                           2, doctors[i].specialisation, 3, fee_text, 4, days_text, -1);
    }
}

static void refresh_appointments_table(void)
{
    int i, p, d;
    GtkTreeIter iter;
    char id_text[16], patient_text[100], doctor_text[100];

    gtk_list_store_clear(appointment_store);
    for (i = 0; i < appointment_count; i++) {
        p = find_patient(appointments[i].patient_id);
        d = find_doctor(appointments[i].doctor_id);
        snprintf(id_text, sizeof(id_text), "%d", appointments[i].id);
        snprintf(patient_text, sizeof(patient_text), "%d - %s", appointments[i].patient_id,
                 p != -1 ? patients[p].full_name : "(removed)");
        snprintf(doctor_text, sizeof(doctor_text), "%d - %s", appointments[i].doctor_id,
                 d != -1 ? doctors[d].name : "(removed)");
        gtk_list_store_append(appointment_store, &iter);
        gtk_list_store_set(appointment_store, &iter, 0, id_text, 1, patient_text,
                           2, doctor_text, 3, appointments[i].date,
                           4, appointments[i].time_slot, 5, appointments[i].status, -1);
    }
}

/* Shows the medical history of the patient typed in the "history" box. */
static void refresh_records_table(void)
{
    char text[40], id_text[16], appt_text[16], medicines_text[250], one[100];
    int patient_id, i, m;
    GtkTreeIter iter;

    gtk_list_store_clear(record_store);
    read_entry(rec_history_patient_entry, text, sizeof(text));
    if (!is_all_digits(text)) {
        return;                                   /* nothing typed yet */
    }
    patient_id = atoi(text);
    for (i = 0; i < record_count; i++) {
        if (records[i].patient_id != patient_id) continue;
        medicines_text[0] = '\0';
        for (m = 0; m < records[i].medicine_count; m++) {
            snprintf(one, sizeof(one), "%s %s x %d days; ", records[i].medicines[m].name,
                     records[i].medicines[m].dosage, records[i].medicines[m].days);
            strncat(medicines_text, one, sizeof(medicines_text) - strlen(medicines_text) - 1);
        }
        snprintf(id_text, sizeof(id_text), "%d", records[i].id);
        snprintf(appt_text, sizeof(appt_text), "%d", records[i].appointment_id);
        gtk_list_store_append(record_store, &iter);
        gtk_list_store_set(record_store, &iter, 0, id_text, 1, records[i].visit_date,
                           2, appt_text, 3, records[i].symptoms, 4, records[i].diagnosis,
                           5, medicines_text, 6, records[i].followup_date, -1);
    }
}

static void refresh_admissions_table(void)
{
    int i, p;
    GtkTreeIter iter;
    char patient_text[100], bed_text[16], days_text[16];

    gtk_list_store_clear(admission_store);
    for (i = 0; i < admission_count; i++) {
        p = find_patient(admissions[i].patient_id);
        snprintf(patient_text, sizeof(patient_text), "%d", admissions[i].patient_id);
        snprintf(bed_text, sizeof(bed_text), "%d", admissions[i].bed_number);
        snprintf(days_text, sizeof(days_text), "%d", admissions[i].days_stayed);
        gtk_list_store_append(admission_store, &iter);
        gtk_list_store_set(admission_store, &iter, 0, patient_text,
                           1, p != -1 ? patients[p].full_name : "(removed)",
                           2, ward_names[admissions[i].ward], 3, bed_text,
                           4, admissions[i].admission_date, 5, admissions[i].discharge_date,
                           6, days_text, 7, admissions[i].is_active ? "In bed" : "Discharged", -1);
    }
}

static void refresh_bills_table(void)
{
    int i, p;
    GtkTreeIter iter;
    char id_text[16], patient_text[16], gross[32], insurance[32], discount[48], net[32];

    gtk_list_store_clear(bill_store);
    for (i = 0; i < bill_count; i++) {
        p = find_patient(bills[i].patient_id);
        snprintf(id_text, sizeof(id_text), "%d", bills[i].id);
        snprintf(patient_text, sizeof(patient_text), "%d", bills[i].patient_id);
        snprintf(gross, sizeof(gross), "%.0f", bills[i].gross_total);
        snprintf(insurance, sizeof(insurance), "%.0f", bills[i].insurance_covered);
        snprintf(discount, sizeof(discount), "%.0f (%d%%)", bills[i].discount_amount,
                 bills[i].discount_percent);
        snprintf(net, sizeof(net), "%.0f", bills[i].net_payable);
        gtk_list_store_append(bill_store, &iter);
        gtk_list_store_set(bill_store, &iter, 0, id_text, 1, patient_text,
                           2, p != -1 ? patients[p].full_name : "(removed)",
                           3, gross, 4, insurance, 5, discount, 6, net,
                           7, bills[i].status, -1);
    }
}

/* Fills the history table, using the three filter boxes (blank = no filter). */
static void refresh_history_table(void)
{
    char patient_text[40], doctor_text[40], date_text[20];
    char patient_cell[16], doctor_cell[16];
    int patient_filter = 0, doctor_filter = 0;
    int i;
    GtkTreeIter iter;

    read_entry(hist_patient_entry, patient_text, sizeof(patient_text));
    read_entry(hist_doctor_entry, doctor_text, sizeof(doctor_text));
    read_entry(hist_date_entry, date_text, sizeof(date_text));
    if (is_all_digits(patient_text)) patient_filter = atoi(patient_text);
    if (is_all_digits(doctor_text))  doctor_filter = atoi(doctor_text);

    gtk_list_store_clear(history_store);
    for (i = 0; i < history_count; i++) {
        if (patient_filter != 0 && history[i].patient_id != patient_filter) continue;
        if (doctor_filter != 0 && history[i].doctor_id != doctor_filter) continue;
        /* the first 10 characters of the timestamp are the date */
        if (date_text[0] != '\0' && strncmp(history[i].timestamp, date_text, 10) != 0) continue;

        if (history[i].patient_id == 0) strcpy(patient_cell, "-");
        else snprintf(patient_cell, sizeof(patient_cell), "%d", history[i].patient_id);
        if (history[i].doctor_id == 0) strcpy(doctor_cell, "-");
        else snprintf(doctor_cell, sizeof(doctor_cell), "%d", history[i].doctor_id);

        gtk_list_store_append(history_store, &iter);
        gtk_list_store_set(history_store, &iter, 0, history[i].timestamp,
                           1, history[i].operation, 2, patient_cell, 3, doctor_cell,
                           4, history[i].description, -1);
    }
}

static void refresh_all_tables(void)
{
    refresh_patients_table();
    refresh_doctors_table();
    refresh_appointments_table();
    refresh_records_table();
    refresh_admissions_table();
    refresh_bills_table();
    refresh_history_table();
}

/* Called after every successful change: save to disk and redraw the tables. */
static void after_change(void)
{
    save_all_data();
    refresh_all_tables();
}

/* ====================================================================
 *  PART 3 - BUTTON HANDLERS
 *  Pattern: read boxes -> call logic function -> show result dialog.
 * ==================================================================== */

/* ---------- Patients ---------- */

static void on_add_patient_clicked(GtkWidget *button, gpointer data)
{
    Patient p;
    char msg[MSG_SIZE];
    (void)button; (void)data;

    memset(&p, 0, sizeof(Patient));
    if (!read_int_field(pat_id_entry, "Patient ID", &p.id)) return;
    read_entry(pat_name_entry, p.full_name, sizeof(p.full_name));
    read_entry(pat_dob_entry, p.dob, sizeof(p.dob));
    read_combo(pat_gender_combo, p.gender, sizeof(p.gender));
    read_entry(pat_phone_entry, p.phone, sizeof(p.phone));
    read_entry(pat_address_entry, p.address, sizeof(p.address));
    read_combo(pat_blood_combo, p.blood_group, sizeof(p.blood_group));
    read_entry(pat_allergy_entry, p.allergies, sizeof(p.allergies));
    read_entry(pat_emergency_entry, p.emergency_contact, sizeof(p.emergency_contact));
    read_combo(pat_insurance_combo, p.insurance, sizeof(p.insurance));

    if (!add_patient(&p, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    show_message(GTK_MESSAGE_INFO, "Patient registered successfully.");

    /* clear the form for the next patient */
    gtk_entry_set_text(GTK_ENTRY(pat_id_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_name_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_dob_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_phone_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_address_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_allergy_entry), "");
    gtk_entry_set_text(GTK_ENTRY(pat_emergency_entry), "");
}

static void on_remove_patient_clicked(GtkWidget *button, gpointer data)
{
    int patient_id;
    char msg[MSG_SIZE], question[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(pat_remove_entry, "Patient ID", &patient_id)) return;
    if (!can_remove_patient(patient_id, msg)) {      /* admitted / unpaid / unknown */
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    snprintf(question, sizeof(question), "Really remove patient %d (%s)?", patient_id,
             patients[find_patient(patient_id)].full_name);
    if (!ask_yes_no(question)) return;

    if (remove_patient(patient_id, msg)) {
        after_change();
        gtk_entry_set_text(GTK_ENTRY(pat_remove_entry), "");
        show_message(GTK_MESSAGE_INFO, "Patient removed.");
    } else {
        show_message(GTK_MESSAGE_ERROR, msg);
    }
}

/* ---------- Doctors ---------- */

static void on_add_doctor_clicked(GtkWidget *button, gpointer data)
{
    Doctor d;
    char msg[MSG_SIZE];
    int i;
    (void)button; (void)data;

    memset(&d, 0, sizeof(Doctor));
    if (!read_int_field(doc_id_entry, "Doctor ID", &d.id)) return;
    read_entry(doc_name_entry, d.name, sizeof(d.name));
    read_combo(doc_spec_combo, d.specialisation, sizeof(d.specialisation));
    if (!read_double_field(doc_fee_entry, "Consultation fee", &d.consultation_fee, 0)) return;
    for (i = 0; i < 7; i++) {
        d.available_days[i] =
            gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(doc_day_checks[i])) ? 1 : 0;
    }

    if (!add_doctor(&d, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    show_message(GTK_MESSAGE_INFO, "Doctor added successfully.");
    gtk_entry_set_text(GTK_ENTRY(doc_id_entry), "");
    gtk_entry_set_text(GTK_ENTRY(doc_name_entry), "");
    gtk_entry_set_text(GTK_ENTRY(doc_fee_entry), "");
    for (i = 0; i < 7; i++) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(doc_day_checks[i]), FALSE);
    }
}

static void on_remove_doctor_clicked(GtkWidget *button, gpointer data)
{
    int doctor_id = get_selected_id(doctor_tree);
    char msg[MSG_SIZE], question[MSG_SIZE];
    (void)button; (void)data;

    if (doctor_id == -1) {
        show_message(GTK_MESSAGE_ERROR, "Click a doctor in the table first.");
        return;
    }
    snprintf(question, sizeof(question), "Really remove doctor %d (%s)?", doctor_id,
             doctors[find_doctor(doctor_id)].name);
    if (!ask_yes_no(question)) return;

    if (remove_doctor(doctor_id, msg)) {
        after_change();
        show_message(GTK_MESSAGE_INFO, "Doctor removed.");
    } else {
        show_message(GTK_MESSAGE_ERROR, msg);
    }
}

/* ---------- Appointments ---------- */

static void on_schedule_clicked(GtkWidget *button, gpointer data)
{
    int patient_id, doctor_id, new_id;
    char date[11], slot[8], msg[MSG_SIZE], done[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(app_patient_entry, "Patient ID", &patient_id)) return;
    if (!read_int_field(app_doctor_entry, "Doctor ID", &doctor_id)) return;
    read_entry(app_date_entry, date, sizeof(date));
    read_combo(app_slot_combo, slot, sizeof(slot));

    if (!schedule_appointment(patient_id, doctor_id, date, slot, msg, &new_id)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    snprintf(done, sizeof(done), "Appointment booked. Your Appointment ID is %d.", new_id);
    show_message(GTK_MESSAGE_INFO, done);
}

/* Shared by the "Completed" and "Cancel" buttons */
static void change_selected_appointment(const char *new_status)
{
    int appointment_id = get_selected_id(appointment_tree);
    char msg[MSG_SIZE], done[MSG_SIZE];

    if (appointment_id == -1) {
        show_message(GTK_MESSAGE_ERROR, "Click an appointment in the table first.");
        return;
    }
    if (!change_appointment_status(appointment_id, new_status, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    snprintf(done, sizeof(done), "Appointment %d is now %s.", appointment_id, new_status);
    show_message(GTK_MESSAGE_INFO, done);
}

static void on_complete_clicked(GtkWidget *button, gpointer data)
{
    (void)button; (void)data;
    change_selected_appointment("Completed");
}

static void on_cancel_appointment_clicked(GtkWidget *button, gpointer data)
{
    (void)button; (void)data;
    change_selected_appointment("Cancelled");
}

/* ---------- Medical records ---------- */

static void on_save_visit_clicked(GtkWidget *button, gpointer data)
{
    int appointment_id, i, med_count = 0;
    char symptoms[120], diagnosis[80], followup[11], msg[MSG_SIZE], label[60];
    Medicine meds[MAX_MEDICINES];
    int appointment_index;
    char patient_text[16];
    (void)button; (void)data;

    if (!read_int_field(rec_appointment_entry, "Appointment ID", &appointment_id)) return;
    read_entry(rec_symptoms_entry, symptoms, sizeof(symptoms));
    read_entry(rec_diagnosis_entry, diagnosis, sizeof(diagnosis));
    read_entry(rec_followup_entry, followup, sizeof(followup));

    /* Collect only the medicine rows where a name was typed */
    for (i = 0; i < MAX_MEDICINES; i++) {
        read_entry(rec_med_name[i], meds[med_count].name, sizeof(meds[med_count].name));
        if (meds[med_count].name[0] == '\0') continue;          /* empty row: skip */
        read_entry(rec_med_dosage[i], meds[med_count].dosage, sizeof(meds[med_count].dosage));
        snprintf(label, sizeof(label), "Days for medicine %d", i + 1);
        if (!read_int_field(rec_med_days[i], label, &meds[med_count].days)) return;
        med_count++;
    }

    if (!record_visit(appointment_id, symptoms, diagnosis, meds, med_count, followup, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }

    /* Show this patient's history straight away */
    appointment_index = find_appointment(appointment_id);
    snprintf(patient_text, sizeof(patient_text), "%d", appointments[appointment_index].patient_id);
    gtk_entry_set_text(GTK_ENTRY(rec_history_patient_entry), patient_text);
    after_change();
    show_message(GTK_MESSAGE_INFO, "Medical visit recorded.");

    gtk_entry_set_text(GTK_ENTRY(rec_appointment_entry), "");
    gtk_entry_set_text(GTK_ENTRY(rec_symptoms_entry), "");
    gtk_entry_set_text(GTK_ENTRY(rec_diagnosis_entry), "");
    gtk_entry_set_text(GTK_ENTRY(rec_followup_entry), "");
    for (i = 0; i < MAX_MEDICINES; i++) {
        gtk_entry_set_text(GTK_ENTRY(rec_med_name[i]), "");
        gtk_entry_set_text(GTK_ENTRY(rec_med_dosage[i]), "");
        gtk_entry_set_text(GTK_ENTRY(rec_med_days[i]), "");
    }
}

static void on_show_history_clicked(GtkWidget *button, gpointer data)
{
    int patient_id;
    (void)button; (void)data;

    if (!read_int_field(rec_history_patient_entry, "Patient ID", &patient_id)) return;
    if (find_patient(patient_id) == -1) {
        show_message(GTK_MESSAGE_ERROR, "That patient ID does not exist.");
        return;
    }
    refresh_records_table();
}

/* ---------- Admissions ---------- */

static void on_admit_clicked(GtkWidget *button, gpointer data)
{
    int patient_id, ward, bed;
    char date[11], msg[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(adm_patient_entry, "Patient ID", &patient_id)) return;
    ward = gtk_combo_box_get_active(GTK_COMBO_BOX(adm_ward_combo));
    bed = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adm_bed_spin));
    read_entry(adm_date_entry, date, sizeof(date));

    if (!admit_patient(patient_id, ward, bed, date, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    show_message(GTK_MESSAGE_INFO, "Patient admitted successfully.");
}

static void on_discharge_clicked(GtkWidget *button, gpointer data)
{
    int patient_id, admission_index;
    char date[11], msg[MSG_SIZE], done[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(dis_patient_entry, "Patient ID", &patient_id)) return;
    read_entry(dis_date_entry, date, sizeof(date));

    if (!discharge_patient(patient_id, date, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    /* the admission we just closed is the patient's most recent one */
    admission_index = admission_count - 1;
    while (admission_index > 0 && admissions[admission_index].patient_id != patient_id) {
        admission_index--;
    }
    snprintf(done, sizeof(done), "Patient discharged after %d day(s). The bed is free again.",
             admissions[admission_index].days_stayed);
    show_message(GTK_MESSAGE_INFO, done);
}

/* ---------- Billing ---------- */

/* Pop-up window that shows one bill, with Paid / Unpaid / Export buttons. */
static void show_bill_popup(int bill_index)
{
    GtkWidget *dialog, *scrolled, *content;
    GtkTextBuffer *buffer;
    char text[4096], filename[40], done[MSG_SIZE];
    int response;

    dialog = gtk_dialog_new_with_buttons("Patient Bill", GTK_WINDOW(main_window),
                                         GTK_DIALOG_MODAL,
                                         "Mark Paid", RESPONSE_PAID,
                                         "Mark Unpaid", RESPONSE_UNPAID,
                                         "Export to .txt", RESPONSE_EXPORT,
                                         "Close", GTK_RESPONSE_CLOSE, NULL);
    scrolled = make_text_area(&buffer, 470, 400);
    content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_add(GTK_CONTAINER(content), scrolled);

    build_bill_text(bill_index, text, sizeof(text));
    gtk_text_buffer_set_text(buffer, text, -1);
    gtk_widget_show_all(dialog);

    /* Keep the window open until Close is pressed */
    while (1) {
        response = gtk_dialog_run(GTK_DIALOG(dialog));
        if (response == RESPONSE_PAID || response == RESPONSE_UNPAID) {
            set_bill_status(bill_index, response == RESPONSE_PAID ? "Paid" : "Unpaid");
            after_change();                                  /* patient row turns bold/normal */
            build_bill_text(bill_index, text, sizeof(text));
            gtk_text_buffer_set_text(buffer, text, -1);
        } else if (response == RESPONSE_EXPORT) {
            snprintf(filename, sizeof(filename), "bill_%d.txt", bills[bill_index].id);
            if (save_text_file(filename, text)) {
                snprintf(done, sizeof(done), "Bill saved as %s in the program folder.", filename);
                show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_INFO, done);
            } else {
                show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_ERROR, "Could not write the file.");
            }
        } else {
            break;                                           /* Close or window X */
        }
    }
    gtk_widget_destroy(dialog);
}

static void on_generate_bill_clicked(GtkWidget *button, gpointer data)
{
    int patient_id, bill_index;
    double medicine_charges, lab_charges;
    char msg[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(bill_patient_entry, "Patient ID", &patient_id)) return;
    if (!read_double_field(bill_medicine_entry, "Medicine charges", &medicine_charges, 1)) return;
    if (!read_double_field(bill_lab_entry, "Lab test amount", &lab_charges, 1)) return;

    if (!generate_bill(patient_id, medicine_charges, lab_charges, msg, &bill_index)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    show_bill_popup(bill_index);
}

static void on_view_bill_clicked(GtkWidget *button, gpointer data)
{
    int bill_id = get_selected_id(bill_tree);
    int i;
    (void)button; (void)data;

    if (bill_id == -1) {
        show_message(GTK_MESSAGE_ERROR, "Click a bill in the table first.");
        return;
    }
    for (i = 0; i < bill_count; i++) {
        if (bills[i].id == bill_id) {
            show_bill_popup(i);
            return;
        }
    }
}

static void on_discount_clicked(GtkWidget *button, gpointer data)
{
    int patient_id, percent;
    char reason[20], msg[MSG_SIZE];
    (void)button; (void)data;

    if (!read_int_field(disc_patient_entry, "Patient ID", &patient_id)) return;
    if (!read_int_field(disc_percent_entry, "Discount percentage", &percent)) return;
    read_combo(disc_reason_combo, reason, sizeof(reason));

    if (!apply_discount(patient_id, percent, reason, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);        /* e.g. outside 5-20: bill unchanged */
        return;
    }
    after_change();
    show_message(GTK_MESSAGE_INFO, msg);             /* tells the new amount payable */
}

/* ---------- History ---------- */

static void on_filter_clicked(GtkWidget *button, gpointer data)
{
    char text[40];
    (void)button; (void)data;

    read_entry(hist_patient_entry, text, sizeof(text));
    if (text[0] != '\0' && !is_all_digits(text)) {
        show_message(GTK_MESSAGE_ERROR, "Patient ID filter must be a number.");
        return;
    }
    read_entry(hist_doctor_entry, text, sizeof(text));
    if (text[0] != '\0' && !is_all_digits(text)) {
        show_message(GTK_MESSAGE_ERROR, "Doctor ID filter must be a number.");
        return;
    }
    read_entry(hist_date_entry, text, sizeof(text));
    if (text[0] != '\0' && !is_valid_date(text)) {
        show_message(GTK_MESSAGE_ERROR, "Date filter must be a real date: YYYY-MM-DD.");
        return;
    }
    refresh_history_table();
}

static void on_show_all_history_clicked(GtkWidget *button, gpointer data)
{
    (void)button; (void)data;
    gtk_entry_set_text(GTK_ENTRY(hist_patient_entry), "");
    gtk_entry_set_text(GTK_ENTRY(hist_doctor_entry), "");
    gtk_entry_set_text(GTK_ENTRY(hist_date_entry), "");
    refresh_history_table();
}

/* ---------- Report ---------- */

static void on_report_clicked(GtkWidget *button, gpointer data)
{
    GtkWidget *dialog, *scrolled, *content;
    GtkTextBuffer *buffer;
    char text[8192], done[MSG_SIZE];
    int response;
    (void)button; (void)data;

    dialog = gtk_dialog_new_with_buttons("Hospital Report", GTK_WINDOW(main_window),
                                         GTK_DIALOG_MODAL,
                                         "Export Report to .txt", RESPONSE_EXPORT,
                                         "Close", GTK_RESPONSE_CLOSE, NULL);
    scrolled = make_text_area(&buffer, 520, 480);
    content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_add(GTK_CONTAINER(content), scrolled);

    build_report_text(text, sizeof(text));
    gtk_text_buffer_set_text(buffer, text, -1);
    gtk_widget_show_all(dialog);

    while (1) {
        response = gtk_dialog_run(GTK_DIALOG(dialog));
        if (response == RESPONSE_EXPORT) {
            if (save_text_file("report.txt", text)) {
                snprintf(done, sizeof(done), "Report saved as report.txt in the program folder.");
                show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_INFO, done);
            } else {
                show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_ERROR, "Could not write the file.");
            }
        } else {
            break;
        }
    }
    gtk_widget_destroy(dialog);
}

/* ====================================================================
 *  PART 4 - BUILDING THE TABS
 *  Each tab = a form on top (inside a titled frame) + a table below.
 * ==================================================================== */

static GtkWidget *make_tab_box(void)
{
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(box), 10);
    return box;
}

static GtkWidget *build_patients_tab(void)
{
    const char *genders[] = {"Male", "Female", "Other"};
    const char *blood_groups[] = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "Unknown"};
    const char *insurance_types[] = {"None", "Public", "Private"};
    const char *titles[] = {"ID", "Name", "Age", "Gender", "Phone", "Blood", "Insurance", "Status"};
    GtkWidget *box = make_tab_box();
    GtkWidget *grid = make_grid();
    GtkWidget *add_button, *remove_box, *remove_button, *table;

    pat_id_entry = make_entry("e.g. 101", 12);
    pat_name_entry = make_entry("Full name", 22);
    pat_dob_entry = make_date_entry(0);
    pat_gender_combo = make_combo(genders, 3);
    pat_phone_entry = make_entry("digits only", 14);
    pat_address_entry = make_entry("Address", 22);
    pat_blood_combo = make_combo(blood_groups, 9);
    pat_allergy_entry = make_entry("or type None", 22);
    pat_emergency_entry = make_entry("Name / phone", 22);
    pat_insurance_combo = make_combo(insurance_types, 3);

    add_form_row(grid, 0, 0, "Patient ID", pat_id_entry);
    add_form_row(grid, 1, 0, "Full name", pat_name_entry);
    add_form_row(grid, 2, 0, "Date of birth", pat_dob_entry);
    add_form_row(grid, 3, 0, "Gender", pat_gender_combo);
    add_form_row(grid, 0, 1, "Phone", pat_phone_entry);
    add_form_row(grid, 1, 1, "Address", pat_address_entry);
    add_form_row(grid, 2, 1, "Blood group", pat_blood_combo);
    add_form_row(grid, 3, 1, "Allergies", pat_allergy_entry);
    add_form_row(grid, 0, 2, "Emergency contact", pat_emergency_entry);
    add_form_row(grid, 1, 2, "Insurance", pat_insurance_combo);

    add_button = make_button("Add Patient", "primary", G_CALLBACK(on_add_patient_clicked));
    gtk_grid_attach(GTK_GRID(grid), add_button, 5, 3, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Register a new patient", grid), FALSE, FALSE, 0);

    /* remove patient row */
    remove_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(remove_box), 8);
    pat_remove_entry = make_entry("Patient ID", 12);
    remove_button = make_button("Remove Patient", "danger", G_CALLBACK(on_remove_patient_clicked));
    gtk_box_pack_start(GTK_BOX(remove_box), gtk_label_new("Patient ID to remove:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(remove_box), pat_remove_entry, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(remove_box), remove_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(remove_box),
        gtk_label_new("   Colours: red = admitted, orange = has allergies, bold = unpaid bill"),
        FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), remove_box, FALSE, FALSE, 0);

    patient_store = make_store(8, 1);
    table = make_table(patient_store, titles, 8, 1, &patient_tree);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_doctors_tab(void)
{
    const char *specialisations[] = {"General", "Paediatrics", "Surgery", "Cardiology", "Dermatology"};
    const char *titles[] = {"ID", "Name", "Specialisation", "Fee (RWF)", "Available days"};
    GtkWidget *box = make_tab_box();
    GtkWidget *grid = make_grid();
    GtkWidget *days_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    GtkWidget *add_button, *remove_button, *table;
    int i;

    doc_id_entry = make_entry("e.g. 1", 10);
    doc_name_entry = make_entry("Doctor name", 22);
    doc_spec_combo = make_combo(specialisations, 5);
    doc_fee_entry = make_entry("e.g. 15000", 12);
    for (i = 0; i < 7; i++) {
        doc_day_checks[i] = gtk_check_button_new_with_label(day_names[i]);
        gtk_box_pack_start(GTK_BOX(days_box), doc_day_checks[i], FALSE, FALSE, 0);
    }

    add_form_row(grid, 0, 0, "Doctor ID", doc_id_entry);
    add_form_row(grid, 1, 0, "Name", doc_name_entry);
    add_form_row(grid, 0, 1, "Specialisation", doc_spec_combo);
    add_form_row(grid, 1, 1, "Consultation fee", doc_fee_entry);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Available days"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), days_box, 1, 2, 4, 1);

    add_button = make_button("Add Doctor", "primary", G_CALLBACK(on_add_doctor_clicked));
    remove_button = make_button("Remove Selected Doctor", "danger", G_CALLBACK(on_remove_doctor_clicked));
    gtk_grid_attach(GTK_GRID(grid), add_button, 1, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), remove_button, 2, 3, 2, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Manage doctors", grid), FALSE, FALSE, 0);

    doctor_store = make_store(5, 0);
    table = make_table(doctor_store, titles, 5, 0, &doctor_tree);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_appointments_tab(void)
{
    const char *titles[] = {"ID", "Patient", "Doctor", "Date", "Time", "Status"};
    GtkWidget *box = make_tab_box();
    GtkWidget *grid = make_grid();
    GtkWidget *buttons = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *table;

    app_patient_entry = make_entry("Patient ID", 10);
    app_doctor_entry = make_entry("Doctor ID", 10);
    app_date_entry = make_date_entry(1);
    app_slot_combo = make_combo(time_slots, NUM_SLOTS);

    add_form_row(grid, 0, 0, "Patient ID", app_patient_entry);
    add_form_row(grid, 0, 1, "Doctor ID", app_doctor_entry);
    add_form_row(grid, 0, 2, "Date", app_date_entry);
    add_form_row(grid, 0, 3, "Time slot", app_slot_combo);
    gtk_grid_attach(GTK_GRID(grid),
        make_button("Schedule Appointment", "primary", G_CALLBACK(on_schedule_clicked)), 8, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Book an appointment", grid), FALSE, FALSE, 0);

    gtk_box_pack_start(GTK_BOX(buttons), gtk_label_new("Select a row, then:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(buttons),
        make_button("Mark Completed", "primary", G_CALLBACK(on_complete_clicked)), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(buttons),
        make_button("Cancel Appointment", "danger", G_CALLBACK(on_cancel_appointment_clicked)), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), buttons, FALSE, FALSE, 0);

    appointment_store = make_store(6, 0);
    table = make_table(appointment_store, titles, 6, 0, &appointment_tree);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_records_tab(void)
{
    const char *titles[] = {"Record", "Visit date", "Appt", "Symptoms", "Diagnosis", "Medicines", "Follow-up"};
    GtkWidget *box = make_tab_box();
    GtkWidget *grid = make_grid();
    GtkWidget *history_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *table;
    char label[40];
    int i;

    rec_appointment_entry = make_entry("Completed appt ID", 14);
    rec_symptoms_entry = make_entry("Symptoms", 40);
    rec_diagnosis_entry = make_entry("Diagnosis (required)", 40);
    rec_followup_entry = make_date_entry(0);
    add_form_row(grid, 0, 0, "Appointment ID", rec_appointment_entry);
    add_form_row(grid, 1, 0, "Symptoms", rec_symptoms_entry);
    add_form_row(grid, 2, 0, "Diagnosis", rec_diagnosis_entry);
    for (i = 0; i < MAX_MEDICINES; i++) {
        rec_med_name[i] = make_entry("Medicine name", 16);
        rec_med_dosage[i] = make_entry("Dosage e.g. 500mg", 14);
        rec_med_days[i] = make_entry("Days", 5);
        snprintf(label, sizeof(label), "Medicine %d", i + 1);
        add_form_row(grid, i, 1, label, rec_med_name[i]);
        gtk_grid_attach(GTK_GRID(grid), rec_med_dosage[i], 4, i, 1, 1);
        gtk_grid_attach(GTK_GRID(grid), rec_med_days[i], 5, i, 1, 1);
    }
    add_form_row(grid, 3, 0, "Next follow-up", rec_followup_entry);
    gtk_grid_attach(GTK_GRID(grid),
        make_button("Save Visit", "primary", G_CALLBACK(on_save_visit_clicked)), 1, 4, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Record a medical visit", grid), FALSE, FALSE, 0);

    rec_history_patient_entry = make_entry("Patient ID", 10);
    gtk_box_pack_start(GTK_BOX(history_box), gtk_label_new("Medical history of patient ID:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(history_box), rec_history_patient_entry, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(history_box),
        make_button("Show History", "primary", G_CALLBACK(on_show_history_clicked)), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), history_box, FALSE, FALSE, 0);

    record_store = make_store(7, 0);
    table = make_table(record_store, titles, 7, 0, NULL);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_admissions_tab(void)
{
    const char *titles[] = {"Patient ID", "Name", "Ward", "Bed", "Admitted", "Discharged", "Days", "State"};
    GtkWidget *box = make_tab_box();
    GtkWidget *admit_grid = make_grid();
    GtkWidget *discharge_grid = make_grid();
    GtkWidget *table;

    adm_patient_entry = make_entry("Patient ID", 10);
    adm_ward_combo = make_combo(ward_names, NUM_WARDS);
    adm_bed_spin = gtk_spin_button_new_with_range(1, BEDS_PER_WARD, 1);
    adm_date_entry = make_date_entry(1);
    add_form_row(admit_grid, 0, 0, "Patient ID", adm_patient_entry);
    add_form_row(admit_grid, 0, 1, "Ward", adm_ward_combo);
    add_form_row(admit_grid, 0, 2, "Bed number", adm_bed_spin);
    add_form_row(admit_grid, 0, 3, "Admission date", adm_date_entry);
    gtk_grid_attach(GTK_GRID(admit_grid),
        make_button("Admit Patient", "primary", G_CALLBACK(on_admit_clicked)), 8, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Admit a patient (10 beds per ward)", admit_grid), FALSE, FALSE, 0);

    dis_patient_entry = make_entry("Patient ID", 10);
    dis_date_entry = make_date_entry(1);
    add_form_row(discharge_grid, 0, 0, "Patient ID", dis_patient_entry);
    add_form_row(discharge_grid, 0, 1, "Discharge date", dis_date_entry);
    gtk_grid_attach(GTK_GRID(discharge_grid),
        make_button("Discharge Patient", "danger", G_CALLBACK(on_discharge_clicked)), 4, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Discharge a patient", discharge_grid), FALSE, FALSE, 0);

    admission_store = make_store(8, 0);
    table = make_table(admission_store, titles, 8, 0, NULL);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_billing_tab(void)
{
    const char *reasons[] = {"Staff", "Charity", "Senior citizen"};
    const char *titles[] = {"Bill", "Patient ID", "Name", "Gross", "Insurance", "Discount", "Net payable", "Status"};
    GtkWidget *box = make_tab_box();
    GtkWidget *bill_grid = make_grid();
    GtkWidget *disc_grid = make_grid();
    GtkWidget *table;

    bill_patient_entry = make_entry("Patient ID", 10);
    bill_medicine_entry = make_entry("0", 12);
    bill_lab_entry = make_entry("0", 12);
    add_form_row(bill_grid, 0, 0, "Patient ID", bill_patient_entry);
    add_form_row(bill_grid, 0, 1, "Medicine charges", bill_medicine_entry);
    add_form_row(bill_grid, 0, 2, "Lab test amount", bill_lab_entry);
    gtk_grid_attach(GTK_GRID(bill_grid),
        make_button("Generate Bill", "primary", G_CALLBACK(on_generate_bill_clicked)), 6, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Generate a bill", bill_grid), FALSE, FALSE, 0);

    disc_patient_entry = make_entry("Patient ID", 10);
    disc_percent_entry = make_entry("5 to 20", 8);
    disc_reason_combo = make_combo(reasons, 3);
    add_form_row(disc_grid, 0, 0, "Patient ID", disc_patient_entry);
    add_form_row(disc_grid, 0, 1, "Discount %", disc_percent_entry);
    add_form_row(disc_grid, 0, 2, "Reason", disc_reason_combo);
    gtk_grid_attach(GTK_GRID(disc_grid),
        make_button("Apply Discount", "primary", G_CALLBACK(on_discount_clicked)), 6, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Apply a discount to the unpaid bill", disc_grid), FALSE, FALSE, 0);

    gtk_box_pack_start(GTK_BOX(box),
        make_button("Open Selected Bill", "primary", G_CALLBACK(on_view_bill_clicked)), FALSE, FALSE, 0);

    bill_store = make_store(8, 0);
    table = make_table(bill_store, titles, 8, 0, &bill_tree);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_history_tab(void)
{
    const char *titles[] = {"Date & time", "Operation", "Patient", "Doctor", "Description"};
    GtkWidget *box = make_tab_box();
    GtkWidget *grid = make_grid();
    GtkWidget *table;

    hist_patient_entry = make_entry("Patient ID", 10);
    hist_doctor_entry = make_entry("Doctor ID", 10);
    hist_date_entry = make_date_entry(0);
    add_form_row(grid, 0, 0, "Patient ID", hist_patient_entry);
    add_form_row(grid, 0, 1, "Doctor ID", hist_doctor_entry);
    add_form_row(grid, 0, 2, "Date", hist_date_entry);
    gtk_grid_attach(GTK_GRID(grid),
        make_button("Apply Filter", "primary", G_CALLBACK(on_filter_clicked)), 6, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid),
        make_button("Show All", "primary", G_CALLBACK(on_show_all_history_clicked)), 7, 0, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Filter the activity history (leave blank = no filter)", grid), FALSE, FALSE, 0);

    history_store = make_store(5, 0);
    table = make_table(history_store, titles, 5, 0, NULL);
    gtk_box_pack_start(GTK_BOX(box), table, TRUE, TRUE, 0);
    return box;
}

static GtkWidget *build_report_tab(void)
{
    GtkWidget *box = make_tab_box();
    GtkWidget *label = gtk_label_new("Open a summary of patients, appointments, beds, money and highlights.");
    GtkWidget *button = make_button("Generate Report", "primary", G_CALLBACK(on_report_clicked));

    gtk_widget_set_valign(label, GTK_ALIGN_END);
    gtk_widget_set_vexpand(label, TRUE);
    gtk_widget_set_halign(button, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(button, GTK_ALIGN_START);
    gtk_widget_set_vexpand(button, TRUE);
    gtk_box_pack_start(GTK_BOX(box), label, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0);
    return box;
}

/* ====================================================================
 *  LOGIN, LOGOUT AND ACCOUNT TAB
 * ==================================================================== */

static void apply_styles(void);       /* defined further down */

static int logout_requested = 0;      /* set to 1 when the user clicks Logout */
static GtkWidget *acc_old_entry, *acc_new_entry, *acc_confirm_entry;
static GtkWidget *usr_name_entry, *usr_pass_entry, *usr_role_combo;

/* Returns 1 (and clears the flag) if the last window closing was a Logout. */
int was_logout_requested(void)
{
    int answer = logout_requested;
    logout_requested = 0;
    return answer;
}

/* An entry that shows dots instead of the letters */
static GtkWidget *make_password_entry(const char *placeholder)
{
    GtkWidget *entry = make_entry(placeholder, 18);
    gtk_entry_set_visibility(GTK_ENTRY(entry), FALSE);
    return entry;
}

/* Shows the login window. Returns 1 if the user logged in, 0 if they quit
 * or failed 3 times. */
int show_login_dialog(void)
{
    GtkWidget *dialog, *grid, *content, *title_label, *hint_label;
    GtkWidget *user_entry, *password_entry;
    char username[30], password[60], msg[MSG_SIZE], text[MSG_SIZE + 40];
    int attempts = 0, logged_in = 0, response;

    apply_styles();
    dialog = gtk_dialog_new_with_buttons("CareDesk - Login", NULL, GTK_DIALOG_MODAL,
                                         "Login", GTK_RESPONSE_OK,
                                         "Exit", GTK_RESPONSE_CANCEL, NULL);
    gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
    gtk_dialog_set_default_response(GTK_DIALOG(dialog), GTK_RESPONSE_OK);

    title_label = gtk_label_new("CareDesk Hospital Manager - please log in");
    user_entry = make_entry("Username", 20);
    password_entry = make_password_entry("Password");
    gtk_entry_set_activates_default(GTK_ENTRY(user_entry), TRUE);      /* Enter = Login */
    gtk_entry_set_activates_default(GTK_ENTRY(password_entry), TRUE);

    grid = make_grid();
    gtk_grid_attach(GTK_GRID(grid), title_label, 0, 0, 2, 1);
    add_form_row(grid, 1, 0, "Username", user_entry);
    add_form_row(grid, 2, 0, "Password", password_entry);
    if (default_admin_unchanged()) {
        hint_label = gtk_label_new("First time? Use admin / admin123, then change it in the Account tab.");
        gtk_grid_attach(GTK_GRID(grid), hint_label, 0, 3, 2, 1);
    }
    content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_add(GTK_CONTAINER(content), grid);
    gtk_widget_show_all(dialog);

    while (attempts < 3 && !logged_in) {
        response = gtk_dialog_run(GTK_DIALOG(dialog));
        if (response != GTK_RESPONSE_OK) {
            break;                                    /* Exit button or window X */
        }
        read_entry(user_entry, username, sizeof(username));
        /* passwords are NOT trimmed: a space can be part of a password */
        snprintf(password, sizeof(password), "%s", gtk_entry_get_text(GTK_ENTRY(password_entry)));

        if (login_user(username, password, msg)) {
            logged_in = 1;
        } else {
            attempts++;
            gtk_entry_set_text(GTK_ENTRY(password_entry), "");
            if (attempts < 3) {
                snprintf(text, sizeof(text), "%s  Attempts left: %d", msg, 3 - attempts);
                show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_ERROR, text);
                gtk_widget_grab_focus(password_entry);
            }
        }
    }
    if (!logged_in && attempts >= 3) {
        show_message_on(GTK_WINDOW(dialog), GTK_MESSAGE_ERROR,
                        "Too many failed attempts. The program will close.");
    }
    gtk_widget_destroy(dialog);
    save_all_data();                                  /* keeps the login entries in the history */
    return logged_in;
}

static void on_logout_clicked(GtkWidget *button, gpointer data)
{
    (void)button; (void)data;
    if (!ask_yes_no("Log out now?")) return;
    logout_requested = 1;
    gtk_widget_destroy(main_window);      /* main() then shows the login window again */
}

static void on_change_password_clicked(GtkWidget *button, gpointer data)
{
    char old_password[60], new_password[60], confirm[60], msg[MSG_SIZE];
    (void)button; (void)data;

    snprintf(old_password, sizeof(old_password), "%s", gtk_entry_get_text(GTK_ENTRY(acc_old_entry)));
    snprintf(new_password, sizeof(new_password), "%s", gtk_entry_get_text(GTK_ENTRY(acc_new_entry)));
    snprintf(confirm, sizeof(confirm), "%s", gtk_entry_get_text(GTK_ENTRY(acc_confirm_entry)));

    if (!change_password(old_password, new_password, confirm, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    gtk_entry_set_text(GTK_ENTRY(acc_old_entry), "");
    gtk_entry_set_text(GTK_ENTRY(acc_new_entry), "");
    gtk_entry_set_text(GTK_ENTRY(acc_confirm_entry), "");
    show_message(GTK_MESSAGE_INFO, "Password changed successfully.");
}

static void on_add_user_clicked(GtkWidget *button, gpointer data)
{
    char username[30], password[60], role[10], msg[MSG_SIZE];
    (void)button; (void)data;

    read_entry(usr_name_entry, username, sizeof(username));
    snprintf(password, sizeof(password), "%s", gtk_entry_get_text(GTK_ENTRY(usr_pass_entry)));
    read_combo(usr_role_combo, role, sizeof(role));

    if (!add_user(username, password, role, msg)) {
        show_message(GTK_MESSAGE_ERROR, msg);
        return;
    }
    after_change();
    gtk_entry_set_text(GTK_ENTRY(usr_name_entry), "");
    gtk_entry_set_text(GTK_ENTRY(usr_pass_entry), "");
    show_message(GTK_MESSAGE_INFO, "User account created.");
}

/* Asks for confirmation, then fills the empty system with demo data. */
static void run_demo_loader(void)
{
    char msg[MSG_SIZE];

    if (!ask_yes_no("Load sample (demo) data: doctors, patients, appointments, admissions and bills?")) {
        return;
    }
    if (load_demo_data(msg)) {
        after_change();
        show_message(GTK_MESSAGE_INFO, msg);
    } else {
        show_message(GTK_MESSAGE_ERROR, msg);
    }
}

static void on_load_demo_clicked(GtkWidget *button, gpointer data)
{
    (void)button; (void)data;
    run_demo_loader();
}

static GtkWidget *build_account_tab(void)
{
    const char *roles[] = {"Staff", "Admin"};
    GtkWidget *box = make_tab_box();
    GtkWidget *password_grid = make_grid();
    GtkWidget *user_grid = make_grid();
    GtkWidget *demo_box;
    char who[100];

    snprintf(who, sizeof(who), "Logged in as: %s (%s)", users[current_user_index].username,
             users[current_user_index].role);
    gtk_box_pack_start(GTK_BOX(box), gtk_label_new(who), FALSE, FALSE, 0);

    acc_old_entry = make_password_entry("Current password");
    acc_new_entry = make_password_entry("At least 4 characters");
    acc_confirm_entry = make_password_entry("Repeat new password");
    add_form_row(password_grid, 0, 0, "Current password", acc_old_entry);
    add_form_row(password_grid, 1, 0, "New password", acc_new_entry);
    add_form_row(password_grid, 2, 0, "Confirm new password", acc_confirm_entry);
    gtk_grid_attach(GTK_GRID(password_grid),
        make_button("Change Password", "primary", G_CALLBACK(on_change_password_clicked)), 1, 3, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Change my password", password_grid), FALSE, FALSE, 0);

    usr_name_entry = make_entry("New username", 18);
    usr_pass_entry = make_password_entry("Password");
    usr_role_combo = make_combo(roles, 2);
    add_form_row(user_grid, 0, 0, "Username", usr_name_entry);
    add_form_row(user_grid, 1, 0, "Password", usr_pass_entry);
    add_form_row(user_grid, 2, 0, "Role", usr_role_combo);
    gtk_grid_attach(GTK_GRID(user_grid),
        make_button("Add User", "primary", G_CALLBACK(on_add_user_clicked)), 1, 3, 1, 1);
    gtk_box_pack_start(GTK_BOX(box), make_section("Add a user (Admin only)", user_grid), FALSE, FALSE, 0);

    demo_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(demo_box), 10);
    gtk_box_pack_start(GTK_BOX(demo_box),
        gtk_label_new("Fills an empty system with sample doctors, patients, bills and more."),
        FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(demo_box),
        make_button("Load Demo Data", "primary", G_CALLBACK(on_load_demo_clicked)), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), make_section("Demo data (Admin only)", demo_box), FALSE, FALSE, 0);
    return box;
}

/* ====================================================================
 *  PART 5 - STYLE (CSS) AND THE MAIN WINDOW
 * ==================================================================== */

static void apply_styles(void)
{
    static int already_done = 0;          /* the login window and the main window both call this */
    const char *css =
        "window { background: #eef5f5; }"
        ".app-header { background: #0b6e6e; padding: 10px 18px; }"
        ".app-header label { color: white; font-size: 20px; font-weight: bold; }"
        ".app-header label.header-user { font-size: 13px; font-weight: normal; }"
        "frame > label { color: #0b6e6e; font-weight: bold; }"
        "button.primary { background-image: none; background: #0b6e6e; color: white;"
        "                 border-radius: 6px; padding: 5px 14px; text-shadow: none; }"
        "button.primary:hover { background: #108a8a; }"
        "button.danger { background-image: none; background: #b3392b; color: white;"
        "                border-radius: 6px; padding: 5px 14px; text-shadow: none; }"
        "button.danger:hover { background: #cf4636; }"
        "notebook tab { padding: 8px 14px; }";
    GtkCssProvider *provider;

    if (already_done) return;
    already_done = 1;
    provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, css, -1, NULL);
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
                                              GTK_STYLE_PROVIDER(provider),
                                              GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    g_object_unref(provider);
}

void create_main_window(void)
{
    GtkWidget *outer_box, *header, *notebook, *title_label, *user_label, *logout_button;
    char who[100];

    apply_styles();

    main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(main_window), "CareDesk - Hospital Patient Management");
    gtk_window_set_default_size(GTK_WINDOW(main_window), 1150, 760);
    g_signal_connect(main_window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    outer_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    /* header bar: title on the left, user name and Logout button on the right */
    header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    gtk_style_context_add_class(gtk_widget_get_style_context(header), "app-header");
    title_label = gtk_label_new("CareDesk  |  Hospital Patient Management System");
    gtk_widget_set_halign(title_label, GTK_ALIGN_START);
    gtk_box_pack_start(GTK_BOX(header), title_label, TRUE, TRUE, 0);
    snprintf(who, sizeof(who), "User: %s (%s)", users[current_user_index].username,
             users[current_user_index].role);
    user_label = gtk_label_new(who);
    gtk_style_context_add_class(gtk_widget_get_style_context(user_label), "header-user");
    logout_button = make_button("Logout", "danger", G_CALLBACK(on_logout_clicked));
    gtk_box_pack_end(GTK_BOX(header), logout_button, FALSE, FALSE, 0);
    gtk_box_pack_end(GTK_BOX(header), user_label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(outer_box), header, FALSE, FALSE, 0);

    notebook = gtk_notebook_new();
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_patients_tab(), gtk_label_new("Patients"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_doctors_tab(), gtk_label_new("Doctors"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_appointments_tab(), gtk_label_new("Appointments"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_records_tab(), gtk_label_new("Medical Records"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_admissions_tab(), gtk_label_new("Admissions"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_billing_tab(), gtk_label_new("Billing"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_history_tab(), gtk_label_new("Activity History"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_report_tab(), gtk_label_new("Report"));
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), build_account_tab(), gtk_label_new("Account"));
    gtk_box_pack_start(GTK_BOX(outer_box), notebook, TRUE, TRUE, 0);

    gtk_container_add(GTK_CONTAINER(main_window), outer_box);
    refresh_all_tables();                 /* show data loaded from the files */
    gtk_widget_show_all(main_window);

    /* An Admin who opens an empty system is offered the sample data */
    if (patient_count == 0 && doctor_count == 0 &&
        strcmp(users[current_user_index].role, "Admin") == 0) {
        run_demo_loader();
    }
}
