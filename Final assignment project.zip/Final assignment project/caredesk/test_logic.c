/* Console test of logic.c (no GTK): each line prints PASS/FAIL. */
#include <stdio.h>
#include <string.h>
#include "../models.h"
#include "../logic.h"
#include "../validation.h"
#include "../seed.h"
static int fails = 0;
static void check(const char *name, int got, int expected, const char *msg)
{ printf("%s  %-52s %s\n", got == expected ? "PASS" : "FAIL", name, got ? "" : msg); if (got != expected) fails++; }
int main(void)
{
    char m[MSG_SIZE]; Patient p; Doctor d; int id, bi; Medicine med[1];
    memset(&p,0,sizeof p); memset(&d,0,sizeof d);
    p.id=1; strcpy(p.full_name,"Alice Uwase"); strcpy(p.dob,"1990-05-10"); strcpy(p.phone,"0788123456"); strcpy(p.insurance,"Private"); strcpy(p.allergies,"Penicillin");
    check("T1 register valid patient", add_patient(&p,m),1,m);
    check("T2 duplicate patient ID", add_patient(&p,m),0,m);
    Patient q=p; q.id=2; strcpy(q.full_name,""); check("T3 empty name", add_patient(&q,m),0,m);
    q=p; q.id=2; strcpy(q.dob,"2090-01-01"); check("T4 future DOB", add_patient(&q,m),0,m);
    q=p; q.id=2; strcpy(q.phone,"078-812"); check("T5 phone with non-digits", add_patient(&q,m),0,m);
    q=p; q.id=2; strcpy(q.dob,"1990-02-30"); check("T6 impossible date 1990-02-30", add_patient(&q,m),0,m);
    d.id=1; strcpy(d.name,"Mugabo"); strcpy(d.specialisation,"General"); d.consultation_fee=10000; d.available_days[0]=1; d.available_days[2]=1;
    check("T7 add valid doctor", add_doctor(&d,m),1,m);
    Doctor e=d; e.id=2; e.consultation_fee=0; check("T8 fee = 0", add_doctor(&e,m),0,m);
    e=d; e.id=2; memset(e.available_days,0,sizeof e.available_days); check("T9 no available day", add_doctor(&e,m),0,m);
    check("T10 book Monday 2030-01-07 08:00", schedule_appointment(1,1,"2030-01-07","08:00",m,&id),1,m);
    check("T11 same slot again", schedule_appointment(1,1,"2030-01-07","08:00",m,&id),0,m); printf("      msg: %s\n",m);
    check("T12 Sunday 2030-01-06", schedule_appointment(1,1,"2030-01-06","09:00",m,&id),0,m); printf("      msg: %s\n",m);
    check("T13 unknown patient", schedule_appointment(99,1,"2030-01-07","09:00",m,&id),0,m);
    check("T14 visit on Scheduled appt", record_visit(1,"fever","Malaria",med,0,"2030-01-14",m),0,m);
    change_appointment_status(1,"Completed",m);
    check("T15 follow-up before visit date", record_visit(1,"fever","Malaria",med,0,"2030-01-01",m),0,m);
    check("T16 empty diagnosis", record_visit(1,"fever","",med,0,"2030-01-14",m),0,m);
    check("T17 valid visit", record_visit(1,"fever","Malaria",med,0,"2030-01-14",m),1,m);
    check("T18 admit to ICU bed 3", admit_patient(1,1,3,"2030-02-01",m),1,m);
    Patient r=p; r.id=2; strcpy(r.full_name,"Bob"); add_patient(&r,m);
    check("T19 bed 3 ICU already taken", admit_patient(2,1,3,"2030-02-01",m),0,m);
    check("T20 remove admitted patient blocked", remove_patient(1,m),0,m);
    check("T21 discharge same day (min 1 day)", discharge_patient(1,"2030-02-01",m),1,m);
    check("T22 bill: 10000+80000+5000+2000", generate_bill(1,5000,2000,m,&bi),1,m);
    printf("      gross=%.0f covered=%.0f net=%.0f (expect 97000 / 77600 / 19400)\n",bills[bi].gross_total,bills[bi].insurance_covered,bills[bi].net_payable);
    check("T23 discount 25% rejected", apply_discount(1,25,"Staff",m),0,m);
    check("T24 discount 10% accepted", apply_discount(1,10,"Charity",m),1,m); printf("      %s (expect net 17460)\n",m);
    check("T25 remove patient with unpaid bill", remove_patient(1,m),0,m);
    set_bill_status(bi,"Paid");
    check("T26 remove after paid", remove_patient(1,m),1,m);
    /* ---- login and accounts ---- */
    ensure_default_admin();
    check("T27 default admin exists on first run", user_count, 1, "no admin");
    check("T28 wrong password rejected", login_user("admin","wrong",m), 0, m);
    check("T29 unknown user rejected", login_user("nobody","admin123",m), 0, m);
    check("T30 correct login admin/admin123", login_user("admin","admin123",m), 1, m);
    check("T31 admin adds staff user", add_user("nurse1","pass1234","Staff",m), 1, m);
    check("T32 duplicate username blocked", add_user("nurse1","pass1234","Staff",m), 0, m);
    check("T33 short password blocked", add_user("nurse2","123","Staff",m), 0, m);
    check("T34 change password: wrong old", change_password("zzz","newpass","newpass",m), 0, m);
    check("T35 change password: mismatch", change_password("admin123","newpass","other",m), 0, m);
    check("T36 change password OK", change_password("admin123","newpass","newpass",m), 1, m);
    check("T37 old password no longer works", login_user("admin","admin123",m), 0, m);
    check("T38 staff login works", login_user("nurse1","pass1234",m), 1, m);
    check("T39 staff cannot add users", add_user("x1","pass1234","Staff",m), 0, m);
    /* ---- demo data ---- */
    patient_count = doctor_count = appointment_count = record_count = 0;
    admission_count = bill_count = history_count = 0;
    login_user("admin","newpass",m);
    check("T40 demo data loads into empty system", load_demo_data(m), 1, m);
    check("T41 demo: 5 doctors", doctor_count, 5, "");
    check("T42 demo: 10 patients", patient_count, 10, "");
    check("T43 demo: 16 appointments all booked", appointment_count, 16, "");
    check("T44 demo: 11 medical records", record_count, 11, "");
    check("T45 demo: 4 admissions, 5 bills", admission_count == 4 && bill_count == 5, 1, "");
    check("T46 demo: second load refused", load_demo_data(m), 0, m);
    { char big[8192]; build_report_text(big, sizeof big); printf("\n%s\n", big); }
    printf("Weekday 2030-01-07 = %d (0=Mon)  days 2030-01-01..2030-03-01 = %d\n", day_of_week("2030-01-07"), days_between("2030-01-01","2030-03-01"));
    printf("\n%s (%d failures)\n", fails?"SOME FAILED":"ALL PASSED", fails);
    return fails;
}
