/* ui.h - the GTK 3 user interface. */
#ifndef UI_H
#define UI_H

int  show_login_dialog(void);      /* returns 1 if the user logged in          */
void create_main_window(void);     /* builds and shows the whole application   */
int  was_logout_requested(void);   /* 1 if the main window was closed by Logout */

#endif
