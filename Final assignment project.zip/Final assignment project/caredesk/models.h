/* models.h
 * All the data structures (structs), size limits and global arrays.
 * Every other file includes this one, so it is the "map" of our data.
 */
#ifndef MODELS_H
#define MODELS_H

/* ---------- Size limits: we use fixed-size arrays, no malloc needed ---------- */
#define MAX_PATIENTS      500
#define MAX_DOCTORS       50
#define MAX_APPOINTMENTS  2000
#define MAX_RECORDS       2000
#define MAX_ADMISSIONS    1000
#define MAX_BILLS         1000
#define MAX_HISTORY       5000
#define MAX_USERS         20

#define MAX_MEDICINES     3     /* medicines per medical record            */
#define NUM_WARDS         4     /* General, ICU, Maternity, Paediatric     */
#define BEDS_PER_WARD     10    /* every ward has beds numbered 1..10      */
#define NUM_SLOTS         10    /* time slots 08:00 ... 17:00              */

/* ---------- 1. Patient ---------- */
typedef struct {
    int  id;
    char full_name[60];
    char dob[11];               /* "YYYY-MM-DD" */
    char gender[10];            /* Male / Female / Other */
    char phone[20];             /* digits only */
    char address[80];
    char blood_group[8];
    char allergies[80];         /* empty or "None" means no allergy */
    char emergency_contact[60];
    char insurance[10];         /* None / Public / Private */
    char status[12];            /* Outpatient / Admitted / Discharged */
    int  has_unpaid_bill;       /* 0 = no, 1 = yes */
} Patient;

/* ---------- 2. Doctor ---------- */
typedef struct {
    int    id;
    char   name[60];
    char   specialisation[20];  /* General, Paediatrics, Surgery, ... */
    double consultation_fee;
    int    available_days[7];   /* index 0 = Monday ... 6 = Sunday; 1 = works */
} Doctor;

/* ---------- 3. Appointment ---------- */
typedef struct {
    int  id;
    int  patient_id;
    int  doctor_id;
    char date[11];              /* "YYYY-MM-DD" */
    char time_slot[6];          /* "08:00" ... "17:00" */
    char status[12];            /* Scheduled / Completed / Cancelled */
} Appointment;

/* ---------- 4. Medical record ---------- */
typedef struct {
    char name[40];
    char dosage[30];
    int  days;
} Medicine;

typedef struct {
    int      id;
    int      appointment_id;
    int      patient_id;
    char     visit_date[11];
    char     symptoms[120];
    char     diagnosis[80];
    Medicine medicines[MAX_MEDICINES];
    int      medicine_count;
    char     followup_date[11];
} MedicalRecord;

/* ---------- 5. Admission (ward + bed) ---------- */
typedef struct {
    int  patient_id;
    int  ward;                  /* index into ward_names[] (0..3) */
    int  bed_number;            /* 1..BEDS_PER_WARD */
    char admission_date[11];
    char discharge_date[11];    /* empty while still admitted */
    int  days_stayed;
    int  is_active;             /* 1 = still in the bed, 0 = discharged */
} Admission;

/* ---------- 6. Bill ---------- */
typedef struct {
    int    id;
    int    patient_id;
    double consultation_total;
    double bed_charges;
    double medicine_charges;
    double lab_charges;
    double gross_total;
    double insurance_covered;
    int    discount_percent;    /* 0 when no discount was given */
    double discount_amount;
    char   discount_reason[20];
    double net_payable;
    char   status[10];          /* Paid / Unpaid */
} Bill;

/* ---------- 7. Activity history ---------- */
typedef struct {
    char timestamp[20];         /* "YYYY-MM-DD HH:MM:SS" */
    char operation[12];         /* register, appointment, visit, ... */
    int  patient_id;            /* 0 when not about a patient */
    int  doctor_id;             /* 0 when not about a doctor  */
    char description[120];
} HistoryEntry;

/* ---------- 8. User account (for the login screen) ---------- */
typedef struct {
    char         username[30];
    unsigned int password_hash;   /* we never store the real password */
    char         role[10];        /* "Admin" or "Staff" */
} User;

/* ---------- Global arrays and their counters (defined in storage.c) ---------- */
extern Patient       patients[MAX_PATIENTS];
extern int           patient_count;

extern Doctor        doctors[MAX_DOCTORS];
extern int           doctor_count;

extern Appointment   appointments[MAX_APPOINTMENTS];
extern int           appointment_count;

extern MedicalRecord records[MAX_RECORDS];
extern int           record_count;

extern Admission     admissions[MAX_ADMISSIONS];
extern int           admission_count;

extern Bill          bills[MAX_BILLS];
extern int           bill_count;

extern HistoryEntry  history[MAX_HISTORY];
extern int           history_count;

extern User          users[MAX_USERS];
extern int           user_count;

#endif
